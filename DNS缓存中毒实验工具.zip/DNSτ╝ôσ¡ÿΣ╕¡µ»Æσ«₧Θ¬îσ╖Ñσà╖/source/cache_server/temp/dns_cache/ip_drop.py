#!/usr/bin/python3
"""
    This Program will forbin all queries that need com's authority, pay attention!
"""
import os


if __name__ == "__main__":
    ip_list = [
        '101.89.19.165',
        '183.3.226.207',
        '157.255.246.101',
        '123.151.66.78',
        '121.51.160.100',
        '203.205.177.41',
        '183.192.201.116',
        '112.60.1.69',
        '125.39.46.125',
        '58.144.154.100',
        '203.205.221.79',
        '2620:37:e000::53',
        '2001:500:86::86',
        '2001:43f8:110::11',
        '2001:13c7:7012::53',
        '2001:dd8:6::101',
        '2001:67c:e0::2',
        '199.180.182.53',
        '199.253.182.182',
        '196.216.169.11',
        '200.7.86.53',
        '203.119.86.101',
        '193.0.9.2'
    ]
    _cmd_formatter_4 = "sudo iptables -I INPUT -s %s -j DROP"
    _cmd_formatter_6 = "sudo ip6tables -I INPUT -s %s -j DROP"
    for _ip in ip_list:
        if "." in _ip:
            _cmd = _cmd_formatter_4 % (_ip)
            print(">> %s" % (_cmd))
            _tmp_ret = os.popen(_cmd).read()
            print(_tmp_ret)
        if ":" in _ip:
            _cmd = _cmd_formatter_6 % (_ip)
            print(">> %s" % (_cmd))
            _tmp_ret = os.popen(_cmd).read()
            print(_tmp_ret)
    print("OK")
