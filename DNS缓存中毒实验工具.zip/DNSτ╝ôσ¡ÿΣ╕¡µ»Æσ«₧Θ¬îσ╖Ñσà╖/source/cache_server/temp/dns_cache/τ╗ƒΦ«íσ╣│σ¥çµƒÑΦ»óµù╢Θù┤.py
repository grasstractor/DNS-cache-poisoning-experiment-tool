#!/usr/bin/python3
import os
import time
import random
import socket

QUERY = 0
RESPONSE = 1

class DNSMessage:
    def __init__(self, _type=QUERY):
        self.__bytes = None
        self.label_locator = dict()  # # 报文解析Cache
        self.message_type = _type  # # DNS报文类型, 0 为query 1为 response, 只有标识作用
        self.message_id = 0  # # 事务ID
        self.flags = None  # # 标志
        self.questions = None  # # 问题计数
        self.answers_rrs = None  # # 回答资源记录数
        self.authority_rrs = None  # # 权威名称服务器计数
        self.additional_rrs = None  # # 附加资源记录数
        self.queries = []  # # 查询问题区域
        self.answers = []  # # 回答问题区域
        self.authoritative_nameservers = []  # # 权威名称服务器区域
        self.additional_records = []  # # 附加区域信息
        self.other_info = None  # # 保存除了message_id外的其他信息

    def to_bytes(self, _use_other_info=False):
        """
            将类成员写成字节码传输
        :return:
        """
        if _use_other_info and self.other_info is not None:
            return int(self.message_id).to_bytes(2, "big") + self.other_info

        _message_id_bytes = int(self.message_id).to_bytes(2, "big")
        _res = b''
        _res += int(self.flags).to_bytes(2, "big")
        _res += int(self.questions).to_bytes(2, "big")
        _res += int(self.answers_rrs).to_bytes(2, "big")
        _res += int(self.authority_rrs).to_bytes(2, "big")
        _res += int(self.additional_rrs).to_bytes(2, "big")

        for _query in self.queries:
            for label in _query['labels']:
                _res += int(len(label)).to_bytes(1, "big")
                _res += label.encode()
            _res += int(0).to_bytes(1, "big")
            _res += int(_query['type']).to_bytes(2, "big") + int(_query['class']).to_bytes(2, "big")
        _res += self.to_bytes_from_rrs(self.answers)
        _res += self.to_bytes_from_rrs(self.authoritative_nameservers)
        _res += self.to_bytes_from_rrs(self.additional_records)
        self.other_info = _res
        return _message_id_bytes + _res

    @staticmethod
    def to_bytes_from_rrs(_list):
        _part = b''
        for _resource_record in _list:
            for label in _resource_record['name'].split("."):
                _part += int(len(label)).to_bytes(1, "big")
                _part += label.encode()
            _part += int(0).to_bytes(1, "big")
            _part += int(_resource_record['type']).to_bytes(2, "big")
            _part += int(_resource_record['class']).to_bytes(2, "big")
            _part += int(_resource_record['ttl']).to_bytes(4, "big")
            if _resource_record['type'] == 5:
                _part += int(len(_resource_record['address']) + 2).to_bytes(2, "big")
                for label in _resource_record['address'].split("."):
                    _part += int(len(label)).to_bytes(1, "big")
                    _part += label.encode()
                _part += int(0).to_bytes(1, "big")
            elif _resource_record['type'] == 1:
                _part += int(4).to_bytes(2, "big")
                for _p in _resource_record['address'].split("."):
                    _part += int(_p).to_bytes(1, "big")
            elif _resource_record['type'] == 28:
                _part += int(16).to_bytes(2, "big")
                for _p in _resource_record['address'].split(':'):
                    _part += int(_p, 16).to_bytes(2, 'big')
            elif _resource_record['type'] == 2:
                _part += int(len(_resource_record['address']) + 2).to_bytes(2, "big")
                for label in _resource_record['address'].split("."):
                    _part += int(len(label)).to_bytes(1, "big")
                    _part += label.encode()
                _part += int(0).to_bytes(1, "big")
        return _part

    def clear(self, ):
        self.answers.clear()
        self.queries.clear()
        self.authoritative_nameservers.clear()
        self.additional_records.clear()
        self.set_numbers(0, 0, 0, 0, 0, None)

    def parse(self, _bytes: bytes):
        """
            写入类成员里
        :param _bytes:
        :return:
        """
        if _bytes is None:
            return False
        else:
            self.__bytes = _bytes
            # 头部
            self.message_id = int.from_bytes(_bytes[0:2], 'big')
            self.flags = int.from_bytes(_bytes[2:4], 'big')
            self.questions = int.from_bytes(_bytes[4:6], 'big')
            self.answers_rrs = int.from_bytes(_bytes[6:8], 'big')
            self.authority_rrs = int.from_bytes(_bytes[8:10], 'big')
            self.additional_rrs = int.from_bytes(_bytes[10:12], 'big')
            _bytes = _bytes[12:]
            for _ in range(self.questions):
                _query = {'labels': [], 'name': None, "type": None, "class": None}
                while True:
                    _label_len = int.from_bytes(_bytes[0:1], 'big')
                    if _label_len > 0:
                        _bytes = _bytes[1:]
                        _query['labels'].append(_bytes[:_label_len].decode())
                        _bytes = _bytes[_label_len:]
                    else:
                        _bytes = _bytes[1:]
                        break
                _query['name'] = '.'.join(_query['labels'])
                _query['type'] = int.from_bytes(_bytes[0:2], 'big')
                _query['class'] = int.from_bytes(_bytes[2:4], 'big')
                self.queries.append(_query)
            # # 取消query的区域
            _bytes = _bytes[4:]
            for _ in range(self.answers_rrs):
                # # 找到数据再说
                _bytes, _answer = self.parse_rrs(_bytes)
                self.answers.append(_answer)
            # # 取消answers的区域
            for _ in range(self.authority_rrs):
                _bytes, _authority = self.parse_rrs(_bytes)
                self.authoritative_nameservers.append(_authority)
            for _ in range(self.additional_rrs):
                _bytes, _additional = self.parse_rrs(_bytes)
                self.additional_records.append(_additional)
            return True

    def parse_rrs(self, _bytes: bytes or None):
        _resource_record = {'labels': [], 'name': None, 'type': None, 'class': None, 'ttl': None,
                            'data_length': None,
                            'address': None}
        # # 解析labels
        while True:
            _label_len = int.from_bytes(_bytes[0:1], 'big')
            if _label_len >= 12 * 16:
                # # 说明是指针
                _pointer_locator = int.from_bytes(_bytes[1:2], 'big') + _label_len - 12 * 16
                _resource_record['labels'].append(self.cache(_pointer_locator))
                _bytes = _bytes[2:]
                break
            else:
                if _label_len > 0:
                    _bytes = _bytes[1:]  # # 这个是长度量
                    _resource_record['labels'].append(_bytes[:_label_len].decode())  # # 字符串
                    _bytes = _bytes[_label_len:]  # # 偏移
                else:
                    _bytes = _bytes[1:]
                    break
        # # 生成name
        _resource_record['name'] = '.'.join(_resource_record['labels'])
        # # type, class, ttl, data_length
        _resource_record['type'] = int.from_bytes(_bytes[0:2], 'big')
        _resource_record['class'] = int.from_bytes(_bytes[2:4], 'big')
        _resource_record['ttl'] = int.from_bytes(_bytes[4:8], 'big')
        _resource_record['data_length'] = int.from_bytes(_bytes[8:10], 'big')
        _bytes = _bytes[10:]
        # # 添加入记录
        _ip_address_ = []
        if _resource_record['type'] == 1:
            # # A 记录  data_length=4
            for __byte in _bytes[:_resource_record['data_length']]:
                _ip_address_.append(str(__byte))
            _resource_record['address'] = '.'.join(_ip_address_)
            _bytes = _bytes[_resource_record['data_length']:]
        elif _resource_record['type'] == 2 or _resource_record['type'] == 5:
            # # NS记录 or CNAME记录
            _labels = []
            while True:
                _label_len = int.from_bytes(_bytes[0:1], 'big')
                if _label_len >= 12 * 16:
                    # # 说明是指针
                    _pointer_locator = int.from_bytes(_bytes[1:2], 'big') + _label_len - 12 * 16
                    _labels.append(self.cache(_pointer_locator))
                    _bytes = _bytes[2:]
                    break
                else:
                    if _label_len > 0:
                        _bytes = _bytes[1:]  # # 这个是长度量
                        _labels.append(_bytes[:_label_len].decode())  # # 字符串
                        _bytes = _bytes[_label_len:]  # # 偏移
                    else:
                        _bytes = _bytes[1:]
                        break
            _resource_record['address'] = '.'.join(_labels)
        elif _resource_record['type'] == 28:
            _index = 0
            while True:
                if _index + 2 > _resource_record['data_length']:
                    break
                else:
                    _tmp = hex(int.from_bytes(_bytes[_index: _index + 2], 'big'))
                    _ip_address_.append(_tmp[2:])
                _index += 2
            _resource_record['address'] = ':'.join(_ip_address_)
            _bytes = _bytes[_resource_record['data_length']:]
        return _bytes, _resource_record

    def set_bytes(self, _bytes: bytes or None):
        self.__bytes = _bytes

    def cache(self, _locate: int):
        if _locate in self.label_locator:
            return self.label_locator[_locate]
        else:
            # # 去查找
            if self.__bytes is None:
                return None
            else:
                _bytes = self.__bytes[_locate:]
                _labels = []
                while True:
                    _label_len = int.from_bytes(_bytes[0:1], 'big')
                    if _label_len >= 12 * 16:
                        # # 说明是指针
                        _pointer_locator = int.from_bytes(_bytes[1:2], 'big') + _label_len - 12 * 16
                        _labels.append(self.cache(_pointer_locator))
                        _bytes = _bytes[2:]
                        break
                    if _label_len > 0:
                        _bytes = _bytes[1:]
                        _labels.append(_bytes[:_label_len].decode())
                        _bytes = _bytes[_label_len:]
                    else:
                        _bytes = _bytes[1:]
                        break
                _res = '.'.join(_labels)
                self.label_locator[_locate] = _res
                return _res


    def set_numbers(self, _flags, _question_rrs, _answers_rrs, _auth_rrs, _addi_rrs, _query=None):
        self.flags = _flags
        self.questions = _question_rrs
        self.answers_rrs = _answers_rrs
        self.authority_rrs = _auth_rrs
        self.additional_rrs = _addi_rrs
        if _query is not None:
            self.queries.append(_query)


def calc_avg_time():
    print("Ready!")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    _l = []
    _dns_message = DNSMessage(_type=QUERY)
    os.popen("sudo rndc flush").read()
    for i in range(1000):
        _dns_message.message_id = random.randint(0, 0xffff)
        _dns_message.set_numbers(_flags=0x100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
                                 _query={
                                     'labels': [str(_dns_message.message_id) + "+" + str(time.time()), 'qq', 'com'],
                                     'type': 1,
                                     'class': 1
                                 })
        _b = _dns_message.to_bytes()
        print(i, _b)
        sock.sendto(_b, ("127.0.0.1", 53))
        t1 = time.time()
        sock.recvfrom(4096)
        _l.append(time.time() - t1)
        os.popen("sudo rndc flush").read()
    sock.close()
    with open("text.csv", "w", encoding="utf-8") as f:
        for i, item in enumerate(_l):   
            f.write(str(i) + ", " + str(item)+ "\n")

if __name__ == "__main__":
    calc_avg_time()

    


