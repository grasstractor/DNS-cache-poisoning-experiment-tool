# # Imports
import os
import socket
import threading
from scapy.all import send
from scapy.layers.dns import DNS
from scapy.layers.inet import UDP, IP


def test2():
    """
        即使用了并发, 还是不能显著提交速度, 
        必须用原始Socket重新封装一下啦
    """
    _threads = []
    _pkt = IP(dst='10.236.121.253', src='54.43.33.22')/ \
        UDP(dport=53, sport=53)/ \
        DNS(b'\xe3q\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x19969872-1599455334-0280178\x02qq\x03com\x00\x00\x01\x00\x01')
    for _ in range(220):
        _threads.append(threading.Thread(target=send, args=(_pkt)))
    for _t in _threads:
        _t.start()
    for _t in _threads:
        _t.join()

def test3():
    """
        可从其他机器发至本机, 而不从本机到本机
        需要使用原始套接字加快速度 才可以
    """
    _pkt = IP(dst='10.245.146.73', src='54.43.33.22')/ \
        UDP(dport=53, sport=53)/ \
        DNS(b'\xe3q\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x19969872-1599455334-0280178\x02qq\x03com\x00\x00\x01\x00\x01')
    # sock = socket.socket(socket.PF_PACKET, socket.SOCK_RAW)
    _b = _pkt.build()
    send(_pkt, count=1000)
    # sock.send(_pkt.build())
    # print(_pkt.build().__class__)

if __name__ == "__main__":
    # main()
    # test2()
    test3()    