#!/usr/bin/python3
from change_bind_version.main import main

if __name__ == "__main__":
    main()
