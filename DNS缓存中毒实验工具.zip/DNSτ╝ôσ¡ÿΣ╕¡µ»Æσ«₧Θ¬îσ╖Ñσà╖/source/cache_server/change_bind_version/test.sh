if [ ! -e /home/xhy/change_bind_version/named/bind-9.3.1/var ];
then
    echo "creating directory var..."
    mkdir /home/xhy/change_bind_version/named/bind-9.3.1/var
fi
if [ ! -e /home/xhy/change_bind_version/named/bind-9.3.1/var/run ];
then
    echo "creating directory var/run..."
    mkdir /home/xhy/change_bind_version/named/bind-9.3.1/var/run
fi
if [ ! -e /home/xhy/change_bind_version/named/bind-9.3.1/var/run/named.pid ];
then
    echo "creating file var/named/named.pid"
    touch /home/xhy/change_bind_version/named/bind-9.3.1/var/run/named.pid
fi

