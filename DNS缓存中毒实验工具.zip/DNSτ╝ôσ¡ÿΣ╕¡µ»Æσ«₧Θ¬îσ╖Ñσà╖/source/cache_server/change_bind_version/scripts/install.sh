#!/bin/sh
if [ $# != 2 ] ;
then
echo "Usage: bash install.sh bind-root-dir"
exit 255
fi

# apt-get install libtool
# apt-get install libtool-bin
# apt-get install libtool-doc
# apt-get install pkg-config
# apt-get install libuv0.10
# apt-get install libuv1
# apt-get install libuv0.10-dbg
# apt-get install libuv0.10-dev
# apt-get install libuv1-dev
# apt-get install libssl-dev
# apt-get install libcap-dev


./configure --prefix=$1 \
        --sysconfdir=$2 \
        --enable-threads \
        --enable-epoll \
        --disable-ipv6 \
        --disable-chroot \
        --enable-backtrace \
        --enable-symtable \
        && make && make install

make
make install

if [ ! -e $1/var ];
then
    echo "creating directory var..."
    mkdir $1/var
fi
if [ ! -e $1/var/run ];
then
    echo "creating directory var/run..."
    mkdir $1/var/run
fi
if [ ! -e $1/var/run/named.pid ];
then
    echo "creating file var/named/named.pid"
    touch $1/var/run/named.pid
fi
