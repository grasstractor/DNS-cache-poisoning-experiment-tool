#!/usr/bin/python3
DIR_PATH = "/home/xhy/change_bind_version/"
SRC_PATH = DIR_PATH + "src/"
TEMP_PATH = DIR_PATH + "temp/"
DATA_PATH = DIR_PATH + "data/"
NAMED_PATH = DIR_PATH + "named/"
SCRIPTS_PATH = DIR_PATH + "scripts/"

BIND_9_INDEX = "https://downloads.isc.org/isc/bind9/"
BIND_8_INDEX = "https://downloads.isc.org/isc/bind8/src/"
# # DOWNLOAD PARAMS
DOWN_MAX_THREAD_NUM = 64
DOWN_CHUNK_SIZE = 2 ** 14
