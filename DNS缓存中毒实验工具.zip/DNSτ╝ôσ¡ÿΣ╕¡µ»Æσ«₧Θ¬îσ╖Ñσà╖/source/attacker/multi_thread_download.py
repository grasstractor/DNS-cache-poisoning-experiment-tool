import os
import queue
import threading
import requests

MAX_THREAD_NUM = 64
CHUNK_SIZE = 2 ** 14


class Downloader:
    def __init__(self, _url, _f_name):
        self.url = _url
        self.f_name = _f_name
        self.queue = queue.Queue()
        self.failed_chunk = []

    def single_download_thread(self, _fd):
        while self.queue.qsize() > 0:
            _chunk_pos, _start_pos, _end_pos = self.queue.get()
            _headers = {"Range": "bytes=%d-%d" % (_start_pos, _end_pos)}
            print(_chunk_pos, "start:", _start_pos, _end_pos)
            try:
                _r = requests.get(self.url, headers=_headers)
                _fd.seek(_start_pos)
                _fd.write(_r.content)
            except Exception as e:
                print("DOWNLOAD ERROR:", e.__doc__, e.__class__)
                print(_chunk_pos, _start_pos, _end_pos)
                self.queue.put((_chunk_pos, _start_pos, _end_pos))
                continue
            finally:
                print(_chunk_pos, "stop:", _start_pos, _end_pos)

    @staticmethod
    def get_chunk(_content_len):
        if _content_len <= 0:
            print("_content_len < 0, wtf?")
            return []
        else:
            # # Chunk num
            _div, _mod = divmod(_content_len, CHUNK_SIZE)
            _chunk_num = 0
            if _mod > 0:
                _chunk_num = _div + 1
            else:
                _chunk_num = _div
            _ret = []
            for _i in range(_chunk_num - 1):
                _ret.append((_i, _i * CHUNK_SIZE, (_i + 1) * CHUNK_SIZE))
            _ret.append((_chunk_num - 1, (_chunk_num - 1) * CHUNK_SIZE, min(_chunk_num * CHUNK_SIZE, _content_len)))
            return _ret

    def get_file_size(self, try_times=3):
        try:
            _content_len = requests.head(self.url).headers['Content-Length']
            print("%s filesize: " % self.f_name, _content_len)
            return _content_len
        except Exception as e:
            print(e.__doc__, e.__class__)
            if try_times > 0:
                return self.get_file_size(try_times - 1)
            else:
                return -1

    def download(self, try_times=3):
        _content_len = self.get_file_size(try_times)
        if _content_len == -1:
            print("DOWNLOAD ERROR: get size of file failed!")
            return 2
        try:
            _chunks = self.get_chunk(int(_content_len))
            print("total chunks: ", len(_chunks))
            for chunk in _chunks:
                self.queue.put(chunk)
            # # create null file
            _temp_f = open(self.f_name, "w")
            _temp_f.close()
            # # rb+ write in any position
            _f = open(self.f_name, "rb+")
            _file_no = _f.fileno()
            _threads = []
            for _ in range(MAX_THREAD_NUM):
                dup = os.dup(_file_no)
                fd = os.fdopen(dup, "rb+", -1)
                _threads.append(threading.Thread(target=self.single_download_thread, args=(fd,)))
            for _t in _threads:
                _t.start()
            for _t in _threads:
                _t.join()
            _f.close()
            if self.queue.qsize() > 0:
                return 1
            else:
                return 0
        except Exception as e:
            print(e.__doc__, e.__class__)

    def download_flow(self):
        while True:
            _code = self.download(3)
            if _code == 0:
                print("Download OK!")
                break
            elif _code == 2:
                print("Download Failed, cannot get the size of file")
                break
            else:
                continue


if __name__ == "__main__":
    import sys
    url = sys.argv[1]
    print(url)
    f_name = url.split('/')[-1]
    d = Downloader(url, f_name)
    d.download_flow()
