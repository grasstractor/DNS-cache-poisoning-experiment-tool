#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdbool.h"

// bool convert_ip(char *str, char **_ret) {
//     size_t _size = strlen(str);
//     if (_size <= 0) {
//         printf("ERROR: The length of the str given is INVALID!\n");
//         return false;
//     } else {
//         *_ret = (char *) calloc(5, sizeof(char));
//         if (*_ret) {
            
//         } else {
//             printf("ERROR: Alloc return String space FAIL! Length: %ld!\n", _size);
//             return false;
//         }
//     }
// }

bool convert_ip(const char *_str, unsigned char **_ret) {
    (*_ret) = (unsigned char *) calloc(5, sizeof(char));
    if (*_ret) {
        unsigned char _pointer = 0;
        unsigned char _temp = 0;
        for (unsigned char _i = 0; _str[_i] != '\0'; ++_i) {
            if (_str[_i] == '.') {
                (*_ret)[_pointer++] = _temp;
                _temp = 0;
            } else {
                _temp *= 10;
                _temp += _str[_i] - 0x30;
            }
        }
        (*_ret)[_pointer] = _temp;
        return true;
    } else {
        puts("ERROR: Convert to 32-bit word from IP string!, Alloc space error!");
        return false;
    }
}
/**
 * char *user_ip, char *authority_ip, char *target_ip,
            char *_name, char *domain, char *authority_name, char *fake_authority_ip,
            unsigned int _name_count, const unsigned short *_ports, size_t _port_num
 * 
 */ 
void print_prompts(){
    char *prompts[] = {
        "user's ip: ", 
        "authority's ip: ",
        "target ip: ",
        "origin name: ",
        "domain: ",
        "authority's name: ",
        "fake authority's ip: ",
        "test count: ",
        "port scale[max]: ",
        "port scale[min]: ",
        "port num: " 
    };
    for(int i = 0; i < 11; i++){
        printf("%s\n", prompts[i]);
    }
}

int main(int argc, const char* argv[]){
    char *stop_string;
    unsigned short a = strtod(argv[1], &stop_string);
    printf("%d\n", a);
    // char* ret;
    // convert_ip("192.168.0.1", &ret);
    // print_prompts();
    // int *a;
    // printf("%ls\n", a);
    // *a = 1;
    // *b = 2;
    // printf("%d\n", *a);
    return 0;
}