PROJECT_PATH = "/home/xhy/dns_cache_poison/"
CPP_PATH = PROJECT_PATH + "cpp/"
DATA_PATH = PROJECT_PATH + "data/"
LOG_PATH = PROJECT_PATH + "log/"
SRC_PATH = PROJECT_PATH + "src/"
TEMP_PATH = PROJECT_PATH + "temp/"
CONFIG_OK = True
