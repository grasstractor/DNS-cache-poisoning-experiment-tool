from colorama import Fore


DEFAULT_FORE_CONFIG = {
    'info': Fore.WHITE,
    'warn': Fore.LIGHTMAGENTA_EX,
    'error': Fore.RED
}

DEFAULT_EMOJI_CONFIG = {
    'info': '[😊 INFO]:',
    'warn': '[😢 WARN]:',
    'error': '[😭 ERROR]:'
}
DEFAULT_TIP_CONFIG_EMOJI = {
    'info': '[ INFO ]:',
    'warn': '[ WARN ]:',
    'error': '[ ERROR ]:'
}

class BeautifulPrinter:
    def __init__(self, _fore_config=DEFAULT_FORE_CONFIG, _support_emoji=True, _emoji_config=DEFAULT_EMOJI_CONFIG, _tip_config=DEFAULT_TIP_CONFIG_EMOJI):
        self.fore_config = _fore_config
        self.support_emoji = _support_emoji
        self.emoji_config = _emoji_config
        self.tip_config = _tip_config
        if self.support_emoji:
            self.info = lambda x: self.print_with_emoji('info', x)
            self.warn = lambda x: self.print_with_emoji('warn', x)
            self.error = lambda x: self.print_with_emoji('error', x)
        else:
            self.info = lambda x: self.print_without_emoji('info', x)
            self.warn = lambda x: self.print_without_emoji('info', x)
            self.error = lambda x: self.print_without_emoji('info', x)
    
    def print_with_emoji(self, _level, _someting):
        print(self.fore_config[_level], self.emoji_config[_level], _someting)
    
    def print_without_emoji(self, _level, _someting):
        print(self.fore_config[_level], self.tip_config[_level], _someting)

if __name__ == "__main__":
    bp = BeautifulPrinter(_support_emoji=True)
    bp.info("This is a tip!")
    bp.warn("This is a warning!")
    bp.error("This is an error!")
