import random
import socket
import time
from src.basic import DEFAULT_BP
from src.dns_message.dns_message import DNSMessage, QUERY

_by_q_type = {
    'A': 1,
    'NS': 5
}

_by_number = {value: key for key, value in _by_q_type.items()}


def query(_name: str, _type="A ", _server="8.8.8.8", _port=53, _read_times=500000):
    _query_message = DNSMessage(_type=QUERY)
    _query_message.set_numbers(0x0100, 1, 0, 0, 0,
                               _query={
                                   'labels': _name.split("."),
                                   'type': _by_q_type[_type],
                                   'class': 1
                               }
    )
    _query_message.message_id = random.randint(0, 65535)
    _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    _sock.setblocking(False)
    _sock.sendto(_query_message.to_bytes(), (_server, _port))
    DEFAULT_BP.info("QUERY %s's %s Record, Server: %s" %
                    (_name, _type, _server))
    _read_time = 0
    while True:
        try:
            _recv, _addr = _sock.recvfrom(4096)
            break
        except BlockingIOError:
            _read_time += 1
            if _read_time > _read_times:
                DEFAULT_BP.error("QUERY %s's %s Record, Server: %s TIMEOUT" %
                        (_name, _type, _server))
                return None
            else:
                continue
    DEFAULT_BP.info("RESPONSE Received From %s" % _addr[0])
    _query_message.clear()
    _query_message.parse(_recv)
    return _query_message

if __name__ == "__main__":
    print(_by_q_type)
    print(_by_number)
