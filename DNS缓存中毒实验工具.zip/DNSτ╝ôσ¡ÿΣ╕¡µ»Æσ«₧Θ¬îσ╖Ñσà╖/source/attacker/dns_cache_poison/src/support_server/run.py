from app import app

if __name__ == '__main__':
    app.run(debug=False, host="10.245.146.73", port=45736)
