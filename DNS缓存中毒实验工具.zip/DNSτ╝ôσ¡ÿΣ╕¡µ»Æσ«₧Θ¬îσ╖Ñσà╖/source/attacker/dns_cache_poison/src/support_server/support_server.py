"""
Packet Format:
Setter Packet Format:
    transaction id: 2bytes
    domain: some bytes(string endswith four `\0`) 'qq.com\0\0\0\0'
    address: 4 bytes '\123\23\23\2'
Reporter Packet Format:
    transaction id: 2 bytes
    flag: 1 byte
        :: success => 0x00
        :: failure => 0xff
    report: some bytes
        example: file not exists
"""
import os
import time
import socket


class SetterMessage:
    def __init__(self, _transaction_id=None, _domain="", _address=""):
        """
            transaction id: 2bytes
            domain: some bytes(string endswith four `\0`) 'qq.com\0\0\0\0'
            address: 4 bytes '\123\23\23\2'
        """
        self.transaction_id = _transaction_id
        self.domain = _domain
        self.address = _address

    def parse(self, _bytes: bytes):
        self.transaction_id = int.from_bytes(_bytes[0:2], 'big')
        self.address = ['.'.join([str(_b) for _b in _bytes[-4:]])]
        self.domain = _bytes[2: -8].decode()

    def to_bytes(self):
        return int(self.transaction_id).to_bytes(2, 'big') + \
               self.domain.encode() + \
               b'\0\0\0\0' + self.ip_str2bytes(self.address)

    @staticmethod
    def ip_str2bytes(_ip_str: str):
        _ret = b''
        for _i in _ip_str.split("."):
            _ret += int(_i).to_bytes(1, "big")
        return _ret

    def clear(self):
        self.transaction_id = 0x0000
        self.domain = ""
        self.address = ""

    def __str__(self):
        _ret = "SHOW MESSAGE\n"
        _ret += "=" * 20 + "<<=SETTER=MESSAGE=INFO=>>" + "=" * 20 + "\n"
        _ret += "TRANSACTION ID: %d\nDOMAIN: %s\nADDRESS: %s\n" % (self.transaction_id, self.domain, self.address)
        return _ret

    def __repr__(self):
        return self.__str__()


class ReporterMessage:
    def __init__(self, _transaction_id=None, _flag=0xff, _report=""):
        """
            transaction id: 2 bytes
            flag: 1 byte
                :: success => 0x00
                :: failure => 0xff
            report: some bytes
                example: file not exists
        """
        self.transaction_id = _transaction_id
        self.flag = _flag
        self.report = _report

    def parse(self, _bytes: bytes):
        self.transaction_id = int.from_bytes(_bytes[0:2], 'big')
        self.flag = int.from_bytes(_bytes[2:3], 'big')
        self.report = _bytes[3:].decode()

    def to_bytes(self):
        return int(self.transaction_id).to_bytes(2, 'big') + \
               int(self.flag).to_bytes(1, 'big') + \
               self.report.encode()

    def clear(self):
        self.transaction_id = 0x0000
        self.flag = 0xff
        self.report = ""

    def __str__(self):
        _ret = "SHOW MESSAGE\n"
        _ret += "=" * 20 + "<<=REPORTER=MESSAGE=INFO=>>" + "=" * 20 + "\n"
        _ret += "TRANSACTION ID: %d\nFLAG: %s MEANING: %s\nREPORT: %s\n" % (
            self.transaction_id, hex(self.flag), 'SUCCESS' if not self.flag else 'FAILURE', self.report)
        return _ret

    def __repr__(self):
        return self.__str__()


def support_server(_bind_target=None, _name_config_path=None, _zone_file_dir=None):
    """
        Support Server
    :param _bind_target:
    :param _name_config_path:
    :param _zone_file_dir:
    :return:
    """
    assert _name_config_path is not None, "name config path must be given!"
    if _bind_target is None:
        _bind_target = ("152.136.138.123", 8888)
    _good_clients = ['127.0.0.1']
    welcome_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(_bind_target)
    welcome_sock.bind(("152.136.138.123", 2338))
    welcome_sock.listen(20)
    print("Stand By!")
    _zone_file_formatter = """$TTL 3D\n\n@\tIN\tSOA\tns.%s admin.%s ( \
    \n\t\t2008111001\t\t8H\n\t\t2H\n\t\t4W\n\t\t1D)\n@\t\tIN\t\tNS\t\tmakechinagreatagain.top.\n@\t\tIN\t\tMX\t\t10 \
    mail.%s\nwww\t\tIN\t\tA\t\t1.1.1.1\nmail\t\tIN\t\tA\t\t1.1.1.2\n*\t\tIN\t\tA\t\t1.1.1.100\n\n"""
    # # 低性能的循环服务器即可
    _config_append_string = """\nzone "%s" {\n\ttype master;\n\tfile %s;\n};\n"""
    while True:
        _sock, _addr = welcome_sock.accept()
        try:
            if _addr[0] not in _good_clients:
                _sock.close()
                continue
            else:
                _recv = _sock.recv(4096)
                _message = SetterMessage()
                if _recv:
                    _message.parse(_recv)
                    _file_name = os.path.join(_zone_file_dir, "db.%s" % _message.domain)
                    with open(_file_name, "w", encoding="utf-8") as f:
                        f.write(_zone_file_formatter % (_message.domain, _message.domain, _message.domain))
                    with open(_name_config_path, "a", encoding="utf-8") as f:
                        f.write(_config_append_string % (_message.domain, _file_name))
                    print(f"{time.strftime('%X')} INFO: SUCCESS")
                    _send_message = ReporterMessage(_message.transaction_id, 0x00, "SUCCESS!")
                    _sock.send(_send_message.to_bytes())
                    _sock.close()
                else:
                    _send_message = ReporterMessage(_message.transaction_id, 0xff, "RECV IS NULL!")
                    _sock.send(_send_message.to_bytes())
                    _sock.close()
                    continue
        except KeyboardInterrupt:
            _send_message = ReporterMessage(0xffff, 0xff, "SERVER SHUTDOWN!")
            _sock.send(_send_message.to_bytes())
            break
        except Exception as e:
            print(e.__doc__, e.__class__)
            _send_message = ReporterMessage(0xffff, 0xff, "ERROR: " + str(e.__class__).upper())
            _sock.send(_send_message.to_bytes())
    print("Bye")
    welcome_sock.close()


def support_client(_server_ip="127.0.0.1", _server_port=32983, _for_which_domain=None):
    """
        support client, domain can be given by standard input or args `for_which_domain` whose type is list(str)
    :param _server_ip:
    :param _server_port:
    :param _for_which_domain:
    :return:
    """
    _sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _sock.connect((_server_ip, _server_port))
    _message = SetterMessage(0x1234, _for_which_domain[0], _for_which_domain[1])
    _sock.send(_message.to_bytes())
    _recv = _sock.recv(4096)
    _message = ReporterMessage()
    _message.parse(_recv)
    print(_message)


if __name__ == "__main__":
    support_server(_zone_file_dir=r"/etc/named",
                   _name_config_path=r"/etc/named/named.conf.local")
