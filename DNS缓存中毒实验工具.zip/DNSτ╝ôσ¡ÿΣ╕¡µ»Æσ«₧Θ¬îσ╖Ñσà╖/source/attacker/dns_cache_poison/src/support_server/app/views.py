import os
import time
import json
from app import app
from flask import request
import hashlib


class RecvISNull(Exception):
    pass


class ArgumentsNotEnough(Exception):
    pass


class SuccessEvent(Exception):
    pass


class AuthorityFailure(Exception):
    pass


class FileExists(Exception):
    pass


zone_file_dir = "/etc/bind"
name_config_path = "/etc/bind/named.conf.local"
_zone_file_formatter = """$TTL 3D\n\n@\tIN\tSOA\tns.%s admin.%s ( \
\n\t\t2008111001\t\t8H\n\t\t2H\n\t\t4W\n\t\t1D)\n@\t\tIN\t\tNS\t\tns.dnslabattacker.net.\n@\t\tIN\t\tMX\t\t10 \
mail.%s\nwww\t\tIN\t\tA\t\t10.245.146.73\nmail\t\tIN\t\tA\t\t10.245.146.73\n*\t\tIN\t\tA\t\t%s\n\n"""
# # 低性能的循环服务器即可
_config_append_string = """\nzone "%s" {\n\ttype master;\n\tfile "%s";\n};\n"""


@app.route("/", methods=['POST'])
def http_server():
    """
        HTTP Server
    """
    _data = request.form
    _ip = request.remote_addr
    _transaction_id = 0xffff
    _domain = ""
    _address = "10.245.146.73"
    try:
        # _allow_ips = ['222.175.198.10', '221.2.164.16']
        # if _ip not in _allow_ips and '*' not in _allow_ips:
            # raise AuthorityFailure()
        print(_data)
        if not _data:
            raise RecvISNull()
        else:
            _post_message = _data.to_dict()
            _transaction_id = _post_message['transaction_id']
            _domain = _post_message['domain']
            _address = _post_message['address']
            _token = _post_message['token']
            if _token != hashlib.md5("forgive-me".encode()).hexdigest():
                raise AuthorityFailure()
            print(f"{time.strftime('%X')} INFO:", _post_message)
            _file_name = os.path.join(zone_file_dir, "db.%s" % _domain)
            print(f"{time.strftime('%X')} INFO: file name, ", _file_name)
            if os.path.exists(_file_name):
                with open(_file_name, "w", encoding="utf-8") as f:
                    f.write(_zone_file_formatter % (_domain, _domain, _domain, _address))
                print(f"{time.strftime('%X')} INFO: FILE %s EXISTS" % _file_name, os.popen("sudo service bind9 restart").read())
                raise FileExists()
            else:
                with open(_file_name, "w", encoding="utf-8") as f:
                    f.write(_zone_file_formatter % (_domain, _domain, _domain, _address))
                with open(name_config_path, "a", encoding="utf-8") as f:
                    print(f"{time.strftime('%X')} INFO: WRITING")
                    f.write(_config_append_string % (_domain, _file_name))
            print(f"{time.strftime('%X')} INFO: SUCCESS")
            print(f"{time.strftime('%X')} INFO: ", os.popen("sudo service bind9 restart").read())
            raise SuccessEvent()
    except FileExists:
        return json.dumps({'transaction_id': _transaction_id, 'flag': 0xff, 'report': 'FILE EXISTS'})
    except RecvISNull:
        return json.dumps({'transaction_id': _transaction_id, 'flag': 0xff, 'report': 'RECV IS NULL'})
    except SuccessEvent:
        return json.dumps({'transaction_id': _transaction_id, 'flag': 0x00, 'report': 'SUCCESS'})
    except AuthorityFailure:
        return json.dumps({'transaction_id': _transaction_id, 'flag': 0xff, 'report': 'AUTHORITY ERROR'})
    except KeyError:
        return json.dumps({'transaction_id': _transaction_id, 'flag': 0xff, 'report': 'Key Not Found'})
    except Exception as e:
        return json.dumps({'transaction_id': _transaction_id, 'flag': 0xff, 'report': str(e.__class__).upper()})


@app.route("/hacker", methods=['GET'])
def message():
    return "This is just a message!"
