import time
import socket
import random
import threading
from scapy.utils import wrpcap
from scapy.layers.inet import Ether, IP, UDP
from scapy.layers.dns import DNS 
from scapy.packet import NoPayload
from scapy.sendrecv import sniff
from src.basic import DOMAIN_NAMES_LABELS4TEST, get_local_ip, DEFAULT_BP
from src.config import TEMP_PATH
from src.dns_message.dns_message import DNSMessage, RESPONSE, QUERY

RANDOM_FLAG = False
CONTINUE_FLAG = True
PORT_MIN, PORT_MAX = 1024, 65535


class OSDetect:
    def __init__(self):
        self.filter = ['Actiontec MI424WR-GEN3I WAP', 'DD-WRT v24-sp2 (Linux 2.4.37)',
                       'VMware Player virtual NAT device']

    def os_detect(self, _server, ):
        import nmap

        """
            1. 判断是否已经探测过
            2. 如果没有探测过, nmap探测
                3. 执行的命令为: [sudo] nmap <server> -p 53 -P0 -sS -sU -O --host-timeout=100 --osscan-guess
                    server: 传入的server
                    -p 53 指定端口
                    -P0 不使用Ping
                    -sS 发送SYN ... TCP
                    -sU 发送UDP
                    -O 探测操作系统版本
                    --host-timeout 设置主机的超时时间, 忽略不回应的主机, 用来代替ping
                    --osscan-guess 猜测操作系统及其版本

        :param _server:
        :return:
        """
        # # 判断是否已经探测过, 如果已经探测过直接取出对应记录即可, 相当于建立了缓存了
        # r = redis.Redis(decode_responses=True)
        # if r.hexists("ns_flag", _server):
        #     print("%s已经探测" % _server)
        #     return {'ns_os': r.hget("ns_os", _server), "ns_cpe": r.hget("ns_cpe", _server)}
        # # 启动nmap进程对目标进行探测
        nm = nmap.PortScanner()
        nm_ret = nm.scan(hosts=_server, ports='53',
                         arguments='-P0 -sS -sU -O --host-timeout=100 --osscan-guess', )
        kernel, cpe = "unknown", "unknown"
        if len(nm_ret['scan']) != 0:
            _ret_scan = nm_ret['scan'].popitem()[1]
            # # 如果有 则提取信息, 没有就爆出默认
            if 'osmatch' in _ret_scan:
                _ret_os_match = _ret_scan['osmatch']
                _ret_os_match.sort(key=self.take_accuracy, reverse=True)
                if len(_ret_os_match) != 0:
                    _index = 0
                    while _index < len(_ret_os_match) and _ret_os_match[_index]['name'] in self.filter:
                        _index += 1
                    if _index != len(_ret_os_match):
                        os_dict = _ret_os_match[_index]
                        # # 获取kernel和cpe_class
                        kernel = os_dict['name']
                        cpe_class = os_dict['osclass']
                        cpe_class.sort(key=self.take_accuracy, reverse=True)
                        if len(cpe_class[0]['cpe']) != 0:
                            cpe = cpe_class[0]['cpe'][0]
                    else:
                        pass
                else:
                    pass
            else:
                pass
            # # 写入Redis然后返回
        # r.hset("ns_os", _server, kernel)
        # r.hset("ns_cpe", _server, cpe)
        # r.hset("ns_flag", _server, 1)
        # r.close()
        return {'ns_os': kernel, "ns_cpe": cpe}

    @staticmethod
    def take_accuracy(elem):
        """按照结果准确度排序"""
        return elem['accuracy']


class DNSServerRandomServer:
    def __init__(self, _dns_server=None):
        """
            本段代码在控制的权威上运行
        :param _dns_server:
        """
        self.count = 0
        self.max_count = 1000
        self.dns_server = _dns_server
        # # 导入

        # # -1 未探测, 0 探测 非随机 1 探测 随机
        self.port_record = []
        self.last_sniff_res = None
        DEFAULT_BP.info("DNS Server Random Server Ready!")
        # print("Ready!")

    def my_summary(self, _pkt: Ether):
        _ret = {}
        is_dns_flag = False
        while True:
            if isinstance(_pkt, NoPayload):
                self.count += 1
                break
            else:
                if _pkt.name == "Ethernet":
                    _ret[_pkt.name] = {'src': _pkt.fields['src'], 'dst': _pkt.fields['dst']}
                elif _pkt.name == "IP":
                    _ret[_pkt.name] = {'src': _pkt.fields['src'], 'dst': _pkt.fields['dst']}
                elif _pkt.name == "UDP":
                    _ret[_pkt.name] = {'src': _pkt.fields['sport'], 'dst': _pkt.fields['dport']}
                elif _pkt.name == "DNS":
                    is_dns_flag = True
                    self.port_record.append(_ret['UDP']['src'])
                    _ret[_pkt.name] = _pkt.fields, _pkt
                _pkt = _pkt.payload
        if is_dns_flag:
            return "%d %s:%s(%s) => %s:%s(%s)" % (
                self.count, _ret['IP']['src'], _ret['UDP']['src'], _ret['Ethernet']['src'], _ret['IP']['dst'],
                _ret['UDP']['dst'], _ret['Ethernet']['dst'])
        else:
            return None

    def sniff(self):
        self.last_sniff_res = sniff(filter="ip src %s and udp" % self.dns_server, prn=lambda x: self.my_summary(x),
                                    count=self.max_count)

    def save(self, _save_dir=TEMP_PATH):
        _save_path = _save_dir + time.ctime().replace(" ", "-").replace(":", "-") + ".pcap"
        return wrpcap(_save_path, self.last_sniff_res) if self.last_sniff_res is not None else None

    @property
    def is_port_random(self, _threshold=10):
        if len(self.port_record) > 0:
            return len(list(set(self.port_record))) < _threshold
        else:
            raise Exception("还没有开始探测")

    @property
    def port_random_scale(self):
        if len(self.port_record) < 0:
            DEFAULT_BP.error("DNS Server Random Detect, Not Detected Yet")
            # print("Not Detected Yet")
            return None
        else:
            return min(self.port_record), max(self.port_record)

    @staticmethod
    def flow():
        dsr = DNSServerRandomServer("192.168.0.192")
        dsr.max_count = 100
        dsr.sniff()
        print(dsr.port_record)
        print(dsr.is_port_random)
        dsr.save()
        print(dsr.port_random_scale)


def dns_server_random_client(_dns_server="192.168.0.192", _domain=None, _count=100000):
    if _domain is None:
        _domain = ["hanbingtest", 'com']

    def recv_res():
        try:
            import pickle
            _sock_recv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            _sock_recv.bind(("10.245.146.73", 12567))
            _ret = _sock_recv.recvfrom(4096)[0]

            _ret = pickle.loads(_ret)
            _max, _min = max(_ret), min(_ret)
            DEFAULT_BP.info("min=%d, max=%d" % (_min, _max))
            _sock_recv.close()
            global RANDOM_FLAG, CONTINUE_FLAG, PORT_MAX, PORT_MIN
            RANDOM_FLAG = len(set(_ret)) > 10
            CONTINUE_FLAG = False
            PORT_MIN = _min
            PORT_MAX = _max
        except KeyboardInterrupt:
            DEFAULT_BP.warn("User Aborted!")
            _sock_recv.close()

    def send_packet():
        try:    
            _dns_query_message = DNSMessage()
            _dns_query_message = DNSMessage(_type=QUERY)
            DEFAULT_BP.info("Please ensure the supporting server is avaliable, then press <return> to start")
            _tmp = input()
            global CONTINUE_FLAG
            for _ in range(_count):
                _dns_query_message.message_id = random.randint(0, 65535)
                _dns_query_message.queries = []
                _dns_query_message.set_numbers(_flags=0x100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
                                            _query={
                                                'labels': [time.ctime().replace(" ", "-").replace(":", "-") + str(
                                                    _dns_query_message.message_id)] + _domain,
                                                'type': 1,
                                                'class': 1
                                            })
                _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                _sock.sendto(_dns_query_message.to_bytes(), (_dns_server, 53))
                if not CONTINUE_FLAG:
                    break
                _recv = _sock.recvfrom(4096)
        except KeyboardInterrupt:
            DEFAULT_BP.warn("User Aborted!")
            CONTINUE_FLAG = False

    def tip(_interval=10):
        try:        
            _t = 0
            while CONTINUE_FLAG:
                while True:
                    time.sleep(1)
                    if not CONTINUE_FLAG:
                        break
                _t += 10
                DEFAULT_BP.warn("%d Seconds Passed! Maybe The Server Doesn't Start(Cache DNS Server or Detectd!)" % _t)
        except KeyboardInterrupt:
            DEFAULT_BP.warn("User Aborted!")

    import threading

    a = threading.Thread(target=recv_res)
    b = threading.Thread(target=send_packet)
    c = threading.Thread(target=tip, args=(10, ))
    a.start()
    b.start()
    c.start()
    a.join()
    b.join()
    c.join()
    global RANDOM_FLAG
    return RANDOM_FLAG, PORT_MIN, PORT_MAX


def get_fpdns_message_from_other_host(_host="192.168.0.128", _port=12345, _detect_host="192.168.0.1",
                                      _print_flag=True):
    _sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _dns_server = _detect_host
    _sock.connect((_host, _port))
    _sock.send(_dns_server.encode())
    _res = _sock.recv(2048)
    if _print_flag:
        print(">> fpdns -r 1 -t 1 ", _dns_server)
        print(_res.decode().strip())
    _sock.close()
    return _res


def get_fpdns_message(_detect_host, _print_flag=True):
    _command_line = "sudo fpdns -r 1 -t 1 " + _detect_host
    import os

    _res = os.popen(_command_line).read()
    _ret = _res.strip()
    if _print_flag:
        print(_command_line)
        print(_ret)
    return _ret


def current_dns_message_ttl(_dns_server=None, _test_domain_name_labels=None, _rec_ret=None):
    """
        1. 向DNS缓存服务器发送请求报文
        2. 解析返回的DNS响应报文, 主要是rrs的
    :return:
    """
    assert isinstance(_dns_server, str), 'dns server要么为空, 要么为字符串 dns server类型: ' + type(_dns_server)
    _ret = {}
    _dns_query_message = DNSMessage(_type=QUERY)
    _dns_query_message.message_id = random.randint(0, 65535)
    if _test_domain_name_labels is None:
        _test_domain_name_labels = ['www', 'qq', 'com']
    _dns_query_message.set_numbers(_flags=0x100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
                                   _query={
                                       'labels': _test_domain_name_labels,
                                       'type': 1,
                                       'class': 1
                                   })
    _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    _sock.sendto(_dns_query_message.to_bytes(), (_dns_server, 53))
    _res, _ = _sock.recvfrom(8192)
    _dns_query_message.parse(_res)
    # _dns_query_message.show()
    if len(_dns_query_message.answers) <= 0:
        _ret[_dns_server] = -1
        if _rec_ret is not None:
            _rec_ret.append(-1)
    else:
        _ret[_dns_server] = _dns_query_message.answers[0]['ttl']
        if _rec_ret is not None:
            _rec_ret.append(_dns_query_message.answers[0]['ttl'])
    return _ret


def max_dns_message_ttl(_dns_server=None, _test_domain_name_labels_set=None):
    """
        假设DNS缓存服务器对于所有域名的缓存规则都是相同的 ttl
    :param _dns_server: 测试的dns缓存服务器
    :param _test_domain_name_labels_set: 给定的用于测试的域名
    :return: 可以说是一个较小的值
    """
    if _test_domain_name_labels_set is None:
        _test_domain_name_labels_set = DOMAIN_NAMES_LABELS4TEST
    _threads = []
    _ret = []
    for _name in _test_domain_name_labels_set:
        _threads.append(threading.Thread(target=current_dns_message_ttl, args=(_dns_server, _name, _ret)))
    for _thread in _threads:
        _thread.start()
    for _thread in _threads:
        _thread.join()
    print(_ret)
    return {_dns_server: max(_ret)}


if __name__ == "__main__":
    dns_server_random_client(_dns_server="10.245.146.74")
    # DNSServerRandomServer.flow()
    # _max_ttl = max_dns_message_ttl('192.168.0.192')
    # print(_max_ttl)
    # ret = current_dns_message_ttl("8.8.8.8")
    # print(ret)
    # server = "192.168.0.192"
    # ret = OSDetect().os_detect(server)
    # print(ret)
