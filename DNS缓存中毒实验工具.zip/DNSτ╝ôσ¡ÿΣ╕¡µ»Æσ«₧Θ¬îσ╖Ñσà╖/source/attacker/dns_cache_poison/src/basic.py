import time
import socket
import logging
import subprocess
from colorama import Fore

EXCEPTION = 1
APPLICATION = 0
BIG_ENDIAN = 'big'
LITTLE_ENDIAN = 'little'

from .config import LOG_PATH

def execute_command(_cmd, _encoding="utf-8"):
    print("execute shell commmad:>> ", _cmd)
    _process = subprocess.Popen(_cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    while _process.poll() is None:
        _line: str
        _line = _process.stdout.readline().strip()
        if _line:
            print(_line.decode(_encoding, 'ignore'))

IP_FRAMES = 0x1
IP_DECIMAL = 0x10
IP_STR = 0x100
IP_PREFIX = 0x1000

DEFAULT_FORE_CONFIG = {
    'info': Fore.WHITE,
    'warn': Fore.LIGHTMAGENTA_EX,
    'error': Fore.RED
}
DEFAULT_EMOJI_CONFIG = {
    'info': '[😊 INFO %s ]:',
    'warn': '[😢 WARN %s ]:',
    'error': '[😭 ERROR %s ]:'
}
DEFAULT_TIP_CONFIG = {
    'info': '[ INFO %s ]:',
    'warn': '[ WARN %s ]:',
    'error': '[ ERROR %s ]:'
}

DOMAIN_NAMES_LABELS4TEST = [['www', 'facebook', 'com'],
                            ['www', 'youtube', 'com'],
                            ['www', 'baidu', 'com'],
                            ['www', 'yahoo', 'com'],
                            ['www', 'amazon', 'com'],
                            ['www', 'wikipedia', 'org'],
                            ['www', 'google', 'co', 'in'],
                            ['www', 'qq', 'com'],
                            ['www', 'twitter', 'com'],
                            ['www', 'live', 'com'],
                            ['www', 'msn', 'com'],
                            ['www', 'yahoo', 'co', 'jp'],
                            ['www', 'linkedin', 'com'],
                            ['www', 'google', 'co', 'jp'],
                            ['www', 'sina', 'com', 'cn'],
                            ['www', 'bing', 'com'],
                            ['www', 'weibo', 'com'],
                            ['www', 'yandex', 'ru'],
                            ['www', 'vk', 'com'],
                            ['www', 'instagram', 'com'],
                            ['www', 'hao123', 'com'],
                            ['www', 'ebay', 'com'],
                            ['www', 'google', 'de'],
                            ['www', 'amazon', 'co', 'jp'],
                            ['www', 'mail', 'ru'],
                            ['www', 'google', 'co', 'uk'],
                            ['www', 'google', 'ru'],
                            ['www', 'pinterest', 'com'],
                            ['www', '360', 'cn'],
                            ['www', 't', 'co'],
                            ['www', 'reddit', 'com'],
                            ['www', 'google', 'com', 'br'],
                            ['www', 'netflix', 'com'],
                            ['www', 'google', 'fr'],
                            ['www', 'paypal', 'com'],
                            ['www', 'microsoft', 'com'],
                            ['www', 'sohu', 'com'],
                            ['www', 'wordpress', 'com'],
                            ['www', 'blogspot', 'com'],
                            ['www', 'google', 'it'],
                            ['www', 'google', 'es'],
                            ['www', 'onclickads', 'net'],
                            ['www', 'tumblr', 'com'],
                            ['www', 'imgur', 'com'],
                            ['www', 'gmw', 'cn'],
                            ['www', 'ok', 'ru'],
                            ['www', 'xvideos', 'com'],
                            ['www', 'imdb', 'com'],
                            ['www', 'apple', 'com'],
                            ['www', 'fc2', 'com'],
                            ['www', 'stackoverflow', 'com'],
                            ['www', 'google', 'com', 'mx'],
                            ['www', 'ask', 'com'],
                            ['www', 'amazon', 'de'],
                            ['www', 'google', 'com', 'hk'],
                            ['www', 'google', 'com', 'tr'],
                            ['www', 'google', 'ca'],
                            ['www', 'office', 'com'],
                            ['www', 'rakuten', 'co', 'jp'],
                            ['www', 'pornhub', 'com'],
                            ['www', 'google', 'co', 'id'],
                            ['www', 'xinhuanet', 'com'],
                            ['www', 'craigslist', 'org'],
                            ['www', 'tianya', 'cn'],
                            ['www', 'github', 'com'],
                            ['www', 'soso', 'com'],
                            ['www', 'nicovideo', 'jp'],
                            ['www', 'amazon', 'co', 'uk'],
                            ['www', 'amazon', 'in'],
                            ['www', 'blogger', 'com'],
                            ['www', 'kat', 'cr'],
                            ['www', 'outbrain', 'com'],
                            ['www', 'go', 'com'],
                            ['www', 'cnn', 'com'],
                            ['www', 'bongacams', 'com'],
                            ['www', 'pixnet', 'net'],
                            ['www', 'googleusercontent', 'com'],
                            ['www', 'google', 'pl'],
                            ['www', 'adnetworkperformance', 'com'],
                            ['www', '360', 'com'],
                            ['www', 'google', 'com', 'au'],
                            ['www', 'dropbox', 'com'],
                            ['www', 'haosou', 'com'],
                            ['www', 'xhamster', 'com'],
                            ['www', 'adobe', 'com'],
                            ['www', 'naver', 'com'],
                            ['www', 'jd', 'com'],
                            ['www', 'flipkart', 'com'],
                            ['www', 'microsoftonline', 'com'],
                            ['www', 'whatsapp', 'com'],
                            ['www', 'nytimes', 'com'],
                            ['www', 'coccoc', 'com'],
                            ['www', 'chase', 'com'],
                            ['www', 'chinadaily', 'com', 'cn'],
                            ['www', 'bbc', 'co', 'uk'],
                            ['www', 'google', 'com', 'eg'],
                            ['www', 'indiatimes', 'com'],
                            ['www', 'wikia', 'com'],
                            ['www', 'booking', 'com']]

def ip2bytes(_ip: str, _byte_order=BIG_ENDIAN):
    _ip_chunks = _ip.split(".")
    _ret = b''
    for _chunk in _ip_chunks:
        _ret += int(_chunk).to_bytes(1, BIG_ENDIAN)
    return _ret

def calc_udp_checksum(_src: str, _dst: str, _sport: int, _dport: int, _payload: bytes, _byte_order=BIG_ENDIAN):
    # # pseudo header
    _p_len_bytes = int(len(_payload) + 8).to_bytes(2, _byte_order)
    # print(len(_payload))
    _pseudo_header = ip2bytes(_src) + ip2bytes(_dst) + b'\x00\x11' + _p_len_bytes
    # print(_pseudo_header)
    # # udp header
    _udp_header = int(_sport).to_bytes(2, _byte_order) + int(_dport).to_bytes(2, _byte_order) + _p_len_bytes
    _need_calc = _pseudo_header + _udp_header + _payload + b'\x00' if len(_payload) // 2 else b''
    # print([hex(i) for i in _need_calc])
    _sum = 0
    for i in range(0, len(_need_calc), 2):
        _sum += int.from_bytes(_need_calc[i: i + 2], _byte_order)
    while True:
        # print(_sum)
        _div, _mod = divmod(_sum, 0xffff+1)
        if _div == 0:
            break 
        else:
            _sum = _mod + _div
    return (~_sum + 65536).to_bytes(2, _byte_order)


class BeautifulPrinter:
    def __init__(self, _fore_config=DEFAULT_FORE_CONFIG, _support_emoji=True, _emoji_config=DEFAULT_EMOJI_CONFIG, _tip_config=DEFAULT_TIP_CONFIG):
        self.fore_config = _fore_config
        self.support_emoji = _support_emoji
        self.emoji_config = _emoji_config
        self.tip_config = _tip_config
        if self.support_emoji:
            self.info = lambda x: self.print_with_emoji('info', x)
            self.warn = lambda x: self.print_with_emoji('warn', x)
            self.error = lambda x: self.print_with_emoji('error', x)
        else:
            self.info = lambda x: self.print_without_emoji('info', x)
            self.warn = lambda x: self.print_without_emoji('info', x)
            self.error = lambda x: self.print_without_emoji('info', x)
    
    def print_with_emoji(self, _level, _someting):
        print(self.fore_config[_level] + self.emoji_config[_level] % time.ctime(), _someting)
    
    def print_without_emoji(self, _level, _someting):
        print(self.fore_config[_level] + self.tip_config[_level] % time.time(), _someting)

    def reset(self):
        print(Fore.RESET, end="")

DEFAULT_BP = BeautifulPrinter()

def app_log(flag=APPLICATION, msg=""):
    m_handler = None
    m_logger = None
    try:
        if flag == EXCEPTION:
            m_logger = logging.getLogger('ExceptionLog')
            m_handler = logging.FileHandler(LOG_PATH + 'Exception.log')
        elif flag == APPLICATION:
            m_logger = logging.getLogger('AppLog')
            m_handler = logging.FileHandler(LOG_PATH + 'Application.log')
        else:
            return
        m_formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        m_handler.setFormatter(m_formatter)
        m_logger.addHandler(m_handler)
        m_logger.setLevel(logging.DEBUG)
        if flag == EXCEPTION:
            m_logger.exception("exception")
        else:
            m_logger.info(msg)
        m_handler.flush()
    except Exception as e:
        raise e
    finally:
        m_logger.removeHandler(m_handler)
        m_handler.close()

def clear_logs(flag=0):
    if flag == EXCEPTION:
        files = ['Exception.log']
    elif flag == APPLICATION:
        files = ['Application.log']
    elif flag == -1:
        files = ['Exception.log', 'Application.log']
    else:
        files = []
    for _path in files:
        f = open(LOG_PATH + _path, "w", encoding="utf-8")
        f.close()

# # IP类
def is_ip_valid(_ip, _type=IP_STR):
    if 0x1 <= _type < 0x10:
        _type = IP_FRAMES
        if not isinstance(_ip, list):
            return False
        elif len(_ip) != 4:
            return False
        else:
            for _frame in _ip:
                try:
                    if not (0 <= int(_frame) <= 255):
                        return False
                except Exception as e:
                    print(_ip)
                    app_log(EXCEPTION, msg=str(e.__class__) + ":" + str(e))
                    raise e
            return True
    elif 0x10 <= _type < 0x100:
        _type = IP_DECIMAL
        if not isinstance(_ip, int):
            return False
        else:
            return 0 <= _ip < 2 ** 32
    else:
        _type = IP_STR
        if not isinstance(_ip, str):
            return False
        else:
            return is_ip_valid(_ip.split("."), IP_FRAMES)


def json_prettify(__json_str: str):
    import json
    return dict_prettify(json.loads(__json_str))


def dict_prettify(__dict: dict, __tab_part="", __key_masks=None):
    if __key_masks is None:
        __key_masks = []
    for __key, __value in __dict.items():
        if __key in __key_masks:
            continue
        print(__tab_part, __key, ":", sep="")
        if isinstance(__value, list):
            list_prettify(__value, __tab_part + "\t")
        elif isinstance(__value, dict):
            dict_prettify(__value, __tab_part + "\t")
        elif isinstance(__value, int):
            print(__tab_part, hex(__value))
        else:
            print(__tab_part, __value)


def list_prettify(__list: list, __tab_part=""):
    for __item in __list:
        if isinstance(__item, list):
            list_prettify(__item, __tab_part + "\t")
        elif isinstance(__item, dict):
            dict_prettify(__item, __tab_part + "\t")
        elif isinstance(__item, int):
            print(__tab_part, hex(__item))
        else:
            print(__tab_part, __item)


def get_local_ip():
    """
        获取IP地址
    :return:
    """
    return socket.gethostbyname(socket.gethostname())


class IpA:
    def __init__(self, _start_frames, _end=True, valid_len=255):
        self.frames = _start_frames
        self.frames[3] -= 1
        self.end = _end
        self.valid_len = valid_len
        self.is_ip_valid = is_ip_valid

    def __iter__(self):
        return self

    def __str__(self):
        return '.'.join([str(frame) for frame in self.frames])

    def __next__(self):
        self.frames[3] += 1
        self.valid_len -= 1
        if self.valid_len == -1:
            raise StopIteration
        if self.frames[3] == 256:
            self.frames[3] = 0
            self.frames[2] += 1
        if self.frames[2] == 256:
            self.frames[2] = 0
            self.frames[1] += 1
        if self.frames[1] == 256:
            self.frames[1] = 0
            self.frames[0] += 1
        if self.frames[0] == 256:
            self.frames[0] = 0
            if self.end:
                raise StopIteration
        return str(self)


class IpCalc(object):
    def __init__(self):
        self.func_map = {
            IP_FRAMES - IP_DECIMAL: self._to_decimal_from_ip_frames,
            IP_FRAMES - IP_STR: self._to_str_from_ip_frames,
            IP_STR - IP_FRAMES: self._to_ip_frames_from_str,
            IP_STR - IP_DECIMAL: self._to_decimal_from_str,
            IP_DECIMAL - IP_FRAMES: self._to_ip_frames_from_decimal,
            IP_DECIMAL - IP_STR: self._to_str_from_decimal,
            IP_PREFIX: self._range_from_ip_prefix,
            0: lambda x: x
        }

    # # convert
    def convert(self, _obj: str or list or int, _from=0, _to=0):
        return self.func_map[_from - _to](_obj)

    # # to decimal

    @staticmethod
    def _to_decimal_from_ip_frames(ip_frames: list):
        assert ip_frames.__len__() == 4, "Invalid Ip Frame"
        _ret = 0
        _tmp = 0x1000000
        for frame in ip_frames:
            _ret += int(frame) * _tmp
            _tmp //= 0x100
        return _ret

    def _to_decimal_from_str(self, _str: str):
        return self._to_decimal_from_ip_frames(self._to_ip_frames_from_str(_str))

    # # to str
    @staticmethod
    def _to_str_from_ip_frames(_ip_frames: list):
        return '.'.join([str(frame) for frame in _ip_frames])

    def _to_str_from_decimal(self, _decimal: int):
        return self._to_str_from_ip_frames(self._to_ip_frames_from_decimal(_decimal))

    # # to ip_frames
    @staticmethod
    def _to_ip_frames_from_decimal(_decimal: int):
        _ret = []
        while _decimal > 0:
            _ret.append(_decimal % 0x100)
            _decimal //= 0x100
        while len(_ret) < 4:
            _ret.append(0)
        _ret.reverse()
        return _ret

    @staticmethod
    def _to_ip_frames_from_str(_ip_str: str):
        return [int(frame) for frame in _ip_str.split('.')]

    def _range_from_ip_prefix(self, ip_prefix_str: str):
        # # 写出始末IP的数字地址
        assert '/' in ip_prefix_str, "Invalid Ip Prefix str"
        _sets = ip_prefix_str.split('/')
        _host_id_num = 32 - int(_sets[1])
        _in_ip = self._to_ip_frames_from_str(_sets[0])
        _in_ip_to_decimal = self._to_decimal_from_ip_frames(_in_ip)
        _mask = 0xffffffff - (2 ** _host_id_num - 1)
        _start = _in_ip_to_decimal & _mask
        _end = _start + 2 ** _host_id_num
        return _start, _end


if __name__ == "__main__":
    bp = BeautifulPrinter(_support_emoji=True)
    bp.info("This is a tip!")
    bp.warn("This is a warning!")
    bp.error("This is an error!")
