#!/bin/zsh
echo "Server Start"
while : ;
do
	python3 ./detect.py
	echo "Server Restart, OK..."
done
