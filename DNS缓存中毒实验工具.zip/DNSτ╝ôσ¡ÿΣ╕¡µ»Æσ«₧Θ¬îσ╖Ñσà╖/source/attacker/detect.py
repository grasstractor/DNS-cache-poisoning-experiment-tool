import time
import random
import socket
import threading
from scapy.all import wrpcap
from scapy.layers.dns import DNS
from scapy.layers.inet import Ether, IP, UDP
from scapy.sendrecv import sniff
from scapy.packet import ls, NoPayload

QUERY = 0
RESPONSE = 1

class DNSMessage:
    def __init__(self, _type=QUERY):
        self.__bytes = None
        self.label_locator = dict()  # # 报文解析Cache
        self.message_type = _type  # # DNS报文类型, 0 为query 1为 response, 只有标识作用
        self.message_id = 0  # # 事务ID
        self.flags = None  # # 标志
        self.questions = None  # # 问题计数
        self.answers_rrs = None  # # 回答资源记录数
        self.authority_rrs = None  # # 权威名称服务器计数
        self.additional_rrs = None  # # 附加资源记录数
        self.queries = []  # # 查询问题区域
        self.answers = []  # # 回答问题区域
        self.authoritative_nameservers = []  # # 权威名称服务器区域
        self.additional_records = []  # # 附加区域信息
        self.other_info = None  # # 保存除了message_id外的其他信息

    def to_bytes(self, _use_other_info=False):
        """
            将类成员写成字节码传输
        :return:
        """
        if _use_other_info and self.other_info is not None:
            return int(self.message_id).to_bytes(2, "big") + self.other_info

        _message_id_bytes = int(self.message_id).to_bytes(2, "big")
        _res = b''
        _res += int(self.flags).to_bytes(2, "big")
        _res += int(self.questions).to_bytes(2, "big")
        _res += int(self.answers_rrs).to_bytes(2, "big")
        _res += int(self.authority_rrs).to_bytes(2, "big")
        _res += int(self.additional_rrs).to_bytes(2, "big")

        for _query in self.queries:
            for label in _query['labels']:
                _res += int(len(label)).to_bytes(1, "big")
                _res += label.encode()
            _res += int(0).to_bytes(1, "big")
            _res += int(_query['type']).to_bytes(2, "big") + int(_query['class']).to_bytes(2, "big")
        _res += self.to_bytes_from_rrs(self.answers)
        _res += self.to_bytes_from_rrs(self.authoritative_nameservers)
        _res += self.to_bytes_from_rrs(self.additional_records)
        self.other_info = _res
        return _message_id_bytes + _res

    @staticmethod
    def to_bytes_from_rrs(_list):
        _part = b''
        for _resource_record in _list:
            for label in _resource_record['name'].split("."):
                _part += int(len(label)).to_bytes(1, "big")
                _part += label.encode()
            _part += int(0).to_bytes(1, "big")
            _part += int(_resource_record['type']).to_bytes(2, "big")
            _part += int(_resource_record['class']).to_bytes(2, "big")
            _part += int(_resource_record['ttl']).to_bytes(4, "big")
            if _resource_record['type'] == 5:
                _part += int(len(_resource_record['address']) + 2).to_bytes(2, "big")
                for label in _resource_record['address'].split("."):
                    _part += int(len(label)).to_bytes(1, "big")
                    _part += label.encode()
                _part += int(0).to_bytes(1, "big")
            elif _resource_record['type'] == 1:
                _part += int(4).to_bytes(2, "big")
                for _p in _resource_record['address'].split("."):
                    _part += int(_p).to_bytes(1, "big")
            elif _resource_record['type'] == 28:
                _part += int(16).to_bytes(2, "big")
                for _p in _resource_record['address'].split(':'):
                    _part += int(_p, 16).to_bytes(2, 'big')
            elif _resource_record['type'] == 2:
                _part += int(len(_resource_record['address']) + 2).to_bytes(2, "big")
                for label in _resource_record['address'].split("."):
                    _part += int(len(label)).to_bytes(1, "big")
                    _part += label.encode()
                _part += int(0).to_bytes(1, "big")
        return _part

    def clear(self, ):
        self.answers.clear()
        self.queries.clear()
        self.authoritative_nameservers.clear()
        self.additional_records.clear()
        self.set_numbers(0, 0, 0, 0, 0, None)

    def parse(self, _bytes: bytes):
        """
            写入类成员里
        :param _bytes:
        :return:
        """
        if _bytes is None:
            return False
        else:
            self.__bytes = _bytes
            # 头部
            self.message_id = int.from_bytes(_bytes[0:2], 'big')
            self.flags = int.from_bytes(_bytes[2:4], 'big')
            self.questions = int.from_bytes(_bytes[4:6], 'big')
            self.answers_rrs = int.from_bytes(_bytes[6:8], 'big')
            self.authority_rrs = int.from_bytes(_bytes[8:10], 'big')
            self.additional_rrs = int.from_bytes(_bytes[10:12], 'big')
            _bytes = _bytes[12:]
            for _ in range(self.questions):
                _query = {'labels': [], 'name': None, "type": None, "class": None}
                while True:
                    _label_len = int.from_bytes(_bytes[0:1], 'big')
                    if _label_len > 0:
                        _bytes = _bytes[1:]
                        _query['labels'].append(_bytes[:_label_len].decode())
                        _bytes = _bytes[_label_len:]
                    else:
                        _bytes = _bytes[1:]
                        break
                _query['name'] = '.'.join(_query['labels'])
                _query['type'] = int.from_bytes(_bytes[0:2], 'big')
                _query['class'] = int.from_bytes(_bytes[2:4], 'big')
                self.queries.append(_query)
            # # 取消query的区域
            _bytes = _bytes[4:]
            for _ in range(self.answers_rrs):
                # # 找到数据再说
                _bytes, _answer = self.parse_rrs(_bytes)
                self.answers.append(_answer)
            # # 取消answers的区域
            for _ in range(self.authority_rrs):
                _bytes, _authority = self.parse_rrs(_bytes)
                self.authoritative_nameservers.append(_authority)
            for _ in range(self.additional_rrs):
                _bytes, _additional = self.parse_rrs(_bytes)
                self.additional_records.append(_additional)
            return True

    def parse_rrs(self, _bytes: bytes or None):
        _resource_record = {'labels': [], 'name': None, 'type': None, 'class': None, 'ttl': None,
                            'data_length': None,
                            'address': None}
        # # 解析labels
        while True:
            _label_len = int.from_bytes(_bytes[0:1], 'big')
            if _label_len >= 12 * 16:
                # # 说明是指针
                _pointer_locator = int.from_bytes(_bytes[1:2], 'big') + _label_len - 12 * 16
                _resource_record['labels'].append(self.cache(_pointer_locator))
                _bytes = _bytes[2:]
                break
            else:
                if _label_len > 0:
                    _bytes = _bytes[1:]  # # 这个是长度量
                    _resource_record['labels'].append(_bytes[:_label_len].decode())  # # 字符串
                    _bytes = _bytes[_label_len:]  # # 偏移
                else:
                    _bytes = _bytes[1:]
                    break
        # # 生成name
        _resource_record['name'] = '.'.join(_resource_record['labels'])
        # # type, class, ttl, data_length
        _resource_record['type'] = int.from_bytes(_bytes[0:2], 'big')
        _resource_record['class'] = int.from_bytes(_bytes[2:4], 'big')
        _resource_record['ttl'] = int.from_bytes(_bytes[4:8], 'big')
        _resource_record['data_length'] = int.from_bytes(_bytes[8:10], 'big')
        _bytes = _bytes[10:]
        # # 添加入记录
        _ip_address_ = []
        if _resource_record['type'] == 1:
            # # A 记录  data_length=4
            for __byte in _bytes[:_resource_record['data_length']]:
                _ip_address_.append(str(__byte))
            _resource_record['address'] = '.'.join(_ip_address_)
            _bytes = _bytes[_resource_record['data_length']:]
        elif _resource_record['type'] == 2 or _resource_record['type'] == 5:
            # # NS记录 or CNAME记录
            _labels = []
            while True:
                _label_len = int.from_bytes(_bytes[0:1], 'big')
                if _label_len >= 12 * 16:
                    # # 说明是指针
                    _pointer_locator = int.from_bytes(_bytes[1:2], 'big') + _label_len - 12 * 16
                    _labels.append(self.cache(_pointer_locator))
                    _bytes = _bytes[2:]
                    break
                else:
                    if _label_len > 0:
                        _bytes = _bytes[1:]  # # 这个是长度量
                        _labels.append(_bytes[:_label_len].decode())  # # 字符串
                        _bytes = _bytes[_label_len:]  # # 偏移
                    else:
                        _bytes = _bytes[1:]
                        break
            _resource_record['address'] = '.'.join(_labels)
        elif _resource_record['type'] == 28:
            _index = 0
            while True:
                if _index + 2 > _resource_record['data_length']:
                    break
                else:
                    _tmp = hex(int.from_bytes(_bytes[_index: _index + 2], 'big'))
                    _ip_address_.append(_tmp[2:])
                _index += 2
            _resource_record['address'] = ':'.join(_ip_address_)
            _bytes = _bytes[_resource_record['data_length']:]
        return _bytes, _resource_record

    def set_bytes(self, _bytes: bytes or None):
        self.__bytes = _bytes

    def cache(self, _locate: int):
        if _locate in self.label_locator:
            return self.label_locator[_locate]
        else:
            # # 去查找
            if self.__bytes is None:
                return None
            else:
                _bytes = self.__bytes[_locate:]
                _labels = []
                while True:
                    _label_len = int.from_bytes(_bytes[0:1], 'big')
                    if _label_len >= 12 * 16:
                        # # 说明是指针
                        _pointer_locator = int.from_bytes(_bytes[1:2], 'big') + _label_len - 12 * 16
                        _labels.append(self.cache(_pointer_locator))
                        _bytes = _bytes[2:]
                        break
                    if _label_len > 0:
                        _bytes = _bytes[1:]
                        _labels.append(_bytes[:_label_len].decode())
                        _bytes = _bytes[_label_len:]
                    else:
                        _bytes = _bytes[1:]
                        break
                _res = '.'.join(_labels)
                self.label_locator[_locate] = _res
                return _res

    def set_numbers(self, _flags, _question_rrs, _answers_rrs, _auth_rrs, _addi_rrs, _query=None):
        self.flags = _flags
        self.questions = _question_rrs
        self.answers_rrs = _answers_rrs
        self.authority_rrs = _auth_rrs
        self.additional_rrs = _addi_rrs
        if _query is not None:
            self.queries.append(_query)



class OSDetect:
    def __init__(self):
        self.filter = ['Actiontec MI424WR-GEN3I WAP', 'DD-WRT v24-sp2 (Linux 2.4.37)',
                       'VMware Player virtual NAT device']

    def os_detect(self, _server, ):
        import nmap

        """
            1. 判断是否已经探测过
            2. 如果没有探测过, nmap探测
                3. 执行的命令为: [sudo] nmap <server> -p 53 -P0 -sS -sU -O --host-timeout=100 --osscan-guess
                    server: 传入的server
                    -p 53 指定端口
                    -P0 不使用Ping
                    -sS 发送SYN ... TCP
                    -sU 发送UDP
                    -O 探测操作系统版本
                    --host-timeout 设置主机的超时时间, 忽略不回应的主机, 用来代替ping
                    --osscan-guess 猜测操作系统及其版本

        :param _server:
        :return:
        """
        # # 判断是否已经探测过, 如果已经探测过直接取出对应记录即可, 相当于建立了缓存了
        # r = redis.Redis(decode_responses=True)
        # if r.hexists("ns_flag", _server):
        #     print("%s已经探测" % _server)
        #     return {'ns_os': r.hget("ns_os", _server), "ns_cpe": r.hget("ns_cpe", _server)}
        # # 启动nmap进程对目标进行探测
        nm = nmap.PortScanner()
        nm_ret = nm.scan(hosts=_server, ports='53-3306',
                         arguments='-P0 -sS -sU -O --host-timeout=100 --osscan-guess', )
        print(nm_ret)
        kernel, cpe = "unknown", "unknown"
        if len(nm_ret['scan']) != 0:
            _ret_scan = nm_ret['scan'].popitem()[1]
            # # 如果有 则提取信息, 没有就爆出默认
            if 'osmatch' in _ret_scan:
                _ret_os_match = _ret_scan['osmatch']
                _ret_os_match.sort(key=self.take_accuracy, reverse=True)
                if len(_ret_os_match) != 0:
                    _index = 0
                    while _index < len(_ret_os_match) and _ret_os_match[_index]['name'] in self.filter:
                        _index += 1
                    if _index != len(_ret_os_match):
                        os_dict = _ret_os_match['index']
                        # # 获取kernel和cpe_class
                        kernel = os_dict['name']
                        cpe_class = os_dict['osclass']
                        cpe_class.sort(key=self.take_accuracy, reverse=True)
                        if len(cpe_class[0]['cpe'] != 0):
                            cpe = cpe_class[0]['cpe'][0]
                    else:
                        pass
                else:
                    pass
            else:
                pass
            # # 写入Redis然后返回
        # r.hset("ns_os", _server, kernel)
        # r.hset("ns_cpe", _server, cpe)
        # r.hset("ns_flag", _server, 1)
        # r.close()
        return {'ns_os': kernel, "ns_cpe": cpe}

    @staticmethod
    def take_accuracy(elem):
        """按照结果准确度排序"""
        return elem['accuracy']


class DNSServerRandomServer:
    def __init__(self, _dns_server=None):
        """
            本段代码在控制的权威上运行
        :param _dns_server:
        """
        self.count = 0
        self.max_count = 1000
        self.dns_server = _dns_server
        # # 导入

        # # -1 未探测, 0 探测 非随机 1 探测 随机
        self.port_record = []
        self.message_ids = []
        self.last_sniff_res = None
        print("Ready!")

    def my_summary(self, _pkt: Ether):
        _ret = {}
        is_dns_flag = False
        while True:
            if isinstance(_pkt, NoPayload):
                self.count += 1
                break
            else:
                if _pkt.name == "Ethernet":
                    _ret[_pkt.name] = {'src': _pkt.fields['src'], 'dst': _pkt.fields['dst']}
                elif _pkt.name == "IP":
                    _ret[_pkt.name] = {'src': _pkt.fields['src'], 'dst': _pkt.fields['dst']}
                elif _pkt.name == "UDP":
                    _ret[_pkt.name] = {'src': _pkt.fields['sport'], 'dst': _pkt.fields['dport']}
                elif _pkt.name == "DNS":
                    is_dns_flag = True
                    _port = _ret['UDP']['src']
                    if int(_port) != 53:
                        # continue
                        self.port_record.append(_port)
                    # self.port_record.append(_ret['UDP']['src'])
                    _ret[_pkt.name] = _pkt.fields, _pkt
                    self.message_ids.append(_pkt.fields['id'])
                _pkt = _pkt.payload
        if is_dns_flag:
            return "%d %s:%s(%s) => %s:%s(%s)" % (
                self.count, _ret['IP']['src'], _ret['UDP']['src'], _ret['Ethernet']['src'], _ret['IP']['dst'],
                _ret['UDP']['dst'], _ret['Ethernet']['dst'])
        else:
            return None

    def sniff(self):
        self.last_sniff_res = sniff(filter="ip src %s and udp" % self.dns_server, prn=lambda x: self.my_summary(x),
                                    count=self.max_count)

    def save(self, _save_dir="./"):
        _save_path = _save_dir + time.ctime().replace(" ", "-").replace(":", "-") + ".pcap"
        return wrpcap(_save_path, self.last_sniff_res) if self.last_sniff_res is not None else None

    @property
    def is_port_random(self, _threshold=10):
        if len(self.port_record) > 0:
            return len(list(set(self.port_record))) < _threshold
        else:
            raise Exception("还没有开始探测")

    @property
    def port_random_scale(self):
        if len(self.port_record) < 0:
            print("Not Detected Yet")
            return None
        else:
            return min(self.port_record), max(self.port_record)

    @staticmethod
    def flow():
        dsr = DNSServerRandomServer("10.245.146.74")
        dsr.max_count = 500
        dsr.sniff()
        dsr.max_count = 1000
        dsr.port_record = []
        dsr.message_ids = []
        dsr.sniff()
        # print("port scale:", dsr.port_record)
        print("Server: ", dsr.dns_server)
        print("is random: ", dsr.is_port_random)
        # dsr.save()
        print("port random scale: ", dsr.port_random_scale)
        # print("message id: ", dsr.message_ids)
        import socket
        import pickle
        _res_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _res_sock.sendto(pickle.dumps(dsr.port_record), ("10.245.146.73", 12567))
        _res_sock.close()


def dns_server_random_client(_dns_server="192.168.0.192", _domain=None, _count=10000):
    if _domain is None:
        _domain = ["hanbingtest", 'com']
    _dns_query_message = DNSMessage()
    _dns_query_message = DNSMessage(_type=QUERY)
    _tmp = input("请按下回车以开始!")
    for _ in range(_count):
        _dns_query_message.message_id = random.randint(0, 65535)
        _dns_query_message.queries = []
        _dns_query_message.set_numbers(_flags=0x100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
                                       _query={
                                           'labels': [time.ctime().replace(" ", "-").replace(":", "-") + str(
                                               _dns_query_message.message_id)] + _domain,
                                           'type': 1,
                                           'class': 1
                                       })
        _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _sock.sendto(_dns_query_message.to_bytes(), (_dns_server, 53))
        _recv = _sock.recvfrom(4096)
        print(_recv)


def get_fpdns_message_from_other_host(_client_flag=True, _host="192.168.0.128", _port=12345, _detect_host="192.168.0.1",
                                      _print_flag=True):
    if _client_flag:
        _sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        _dns_server = _detect_host
        _sock.connect((_host, _port))
        _sock.send(_dns_server.encode())
        _res = _sock.recv(2048)
        if _print_flag:
            print(">> fpdns -r 1 -t 1 ", _dns_server)
            print(_res.decode().strip())
        _sock.close()
        return _res
    else:
        # # 使用本机的fpdns
        _command_line = "fpdns -r 1 -t 1 " + _detect_host
        import os

        _res = os.popen(_command_line).read()
        return _res


def current_dns_message_ttl(_dns_server=None, _test_domain_name_labels=None, _rec_ret=None):
    """
        1. 向DNS缓存服务器发送请求报文
        2. 解析返回的DNS响应报文, 主要是rrs的
    :return:
    """
    assert isinstance(_dns_server, str), 'dns server要么为空, 要么为字符串 dns server类型: ' + type(_dns_server)
    _ret = {}
    _dns_query_message = DNSMessage(_type=QUERY)
    _dns_query_message.message_id = random.randint(0, 65535)
    if _test_domain_name_labels is None:
        _test_domain_name_labels = ['www', 'qq', 'com']
    _dns_query_message.set_numbers(_flags=0x100, _question_rrs=1, _answers_rrs=0, _auth_rrs=0, _addi_rrs=0,
                                   _query={
                                       'labels': _test_domain_name_labels,
                                       'type': 1,
                                       'class': 1
                                   })
    _sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    _sock.sendto(_dns_query_message.to_bytes(), (_dns_server, 53))
    _res, _ = _sock.recvfrom(8192)
    _dns_query_message.parse(_res)
    # _dns_query_message.show()
    if len(_dns_query_message.answers) <= 0:
        _ret[_dns_server] = -1
        if _rec_ret is not None:
            _rec_ret.append(-1)
    else:
        _ret[_dns_server] = _dns_query_message.answers[0]['ttl']
        if _rec_ret is not None:
            _rec_ret.append(_dns_query_message.answers[0]['ttl'])
    return _ret


def max_dns_message_ttl(_dns_server=None, _test_domain_name_labels_set=None):
    """
        假设DNS缓存服务器对于所有域名的缓存规则都是相同的 ttl
    :param _dns_server: 测试的dns缓存服务器
    :param _test_domain_name_labels_set: 给定的用于测试的域名
    :return: 可以说是一个较小的值
    """
    if _test_domain_name_labels_set is None:
        _test_domain_name_labels_set = ["www.qq.com", "www.google.com"]
    _threads = []
    _ret = []
    for _name in _test_domain_name_labels_set:
        _threads.append(threading.Thread(target=current_dns_message_ttl, args=(_dns_server, _name, _ret)))
    for _thread in _threads:
        _thread.start()
    for _thread in _threads:
        _thread.join()
    print(_ret)
    return {_dns_server: max(_ret)}


if __name__ == "__main__":
    # dns_server_random_client(_dns_server="10.245.146.74")
    DNSServerRandomServer.flow()
    # _max_ttl = max_dns_message_ttl('192.168.0.192')
    # print(_max_ttl)
    # ret = current_dns_message_ttl("8.8.8.8")
    # print(ret)
    # server = "192.168.0.192"
    # ret = OSDetect().os_detect(server)
    # print(ret)
