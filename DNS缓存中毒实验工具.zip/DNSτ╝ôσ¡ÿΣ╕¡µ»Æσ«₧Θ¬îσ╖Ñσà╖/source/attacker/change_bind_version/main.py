#!/usr/bin/python3
import os
import queue
import shutil
import tarfile
import requests
import argparse
import threading
import subprocess

if os.getcwd() == "/home/xhy/change_bind_version":
    from src.basic import *
    from src.variables import DATA_PATH, BIND_9_INDEX, NAMED_PATH, SCRIPTS_PATH, DOWN_CHUNK_SIZE, DOWN_MAX_THREAD_NUM, BIND_8_INDEX
else:
    from .src.basic import *
    from .src.variables import DATA_PATH, BIND_9_INDEX, NAMED_PATH, SCRIPTS_PATH, DOWN_CHUNK_SIZE, DOWN_MAX_THREAD_NUM, BIND_8_INDEX


def execute_command(_cmd, _encoding="utf-8"):
    print("execute shell commmad:>> ", _cmd)
    _process = subprocess.Popen(_cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    while _process.poll() is None:
        _line: str
        _line = _process.stdout.readline().strip()
        if _line:
            print(_line.decode(_encoding, 'ignore'))

def execute_command_with_return(_cmd, _line_flag=True):
    _pipe = os.popen(_cmd)
    if _line_flag:
        return _pipe.readlines()
    else:
        return _pipe.read()

class Downloader:
    def __init__(self, _index=BIND_9_INDEX, _version=None):
        self.index = _index
        self.version = _version
        self.f_name = "bind-%s.tar.gz" % _version
        self.url = _index + _version + "/" + self.f_name
        self.queue = queue.Queue()

    def single_download_thread(self, _fd):
        while self.queue.qsize() > 0:
            _chunk_pos, _start_pos, _end_pos = self.queue.get()
            _headers = {"Range": "bytes=%d-%d" % (_start_pos, _end_pos)}
            print(_chunk_pos, "start:", _start_pos, _end_pos)
            try:
                _r = requests.get(self.url, headers=_headers)
                _fd.seek(_start_pos)
                _fd.write(_r.content)
            except Exception as e:
                raise e
                print("DOWNLOAD ERROR:", e.__doc__, e.__class__)
                print(_chunk_pos, _start_pos, _end_pos)
                self.queue.put((_chunk_pos, _start_pos, _end_pos))
                continue
            finally:
                print(_chunk_pos, "stop:", _start_pos, _end_pos)

    @staticmethod
    def get_chunk(_content_len):
        if _content_len <= 0:
            print("_content_len < 0")
            return []
        else:
            # # Chunk num
            _div, _mod = divmod(_content_len, DOWN_CHUNK_SIZE)
            _chunk_num = 0
            if _mod > 0:
                _chunk_num = _div + 1
            else:
                _chunk_num = _div
            _ret = []
            for _i in range(_chunk_num - 1):
                _ret.append((_i, _i * DOWN_CHUNK_SIZE, (_i + 1) * DOWN_CHUNK_SIZE))
            _ret.append((_chunk_num - 1, (_chunk_num - 1) * DOWN_CHUNK_SIZE, min(_chunk_num * DOWN_CHUNK_SIZE, _content_len)))
            return _ret

    def get_file_size(self, try_times=3):
        try:
            _content_len = requests.head(self.url).headers['Content-Length']
            print("%s filesize: " % self.f_name, _content_len)
            return _content_len
        except Exception as e:
            raise e
            print(e.__doc__, e.__class__)
            if try_times > 0:
                return self.get_file_size(try_times - 1)
            else:
                return -1

    def download(self, try_times=3):
        _content_len = self.get_file_size(try_times)
        if _content_len == -1:
            print("DOWNLOAD ERROR: get size of file failed!")
            return 2
        try:
            _chunks = self.get_chunk(int(_content_len))
            print("total chunks: ", len(_chunks))
            for chunk in _chunks:
                self.queue.put(chunk)
            # # create null file
            _temp_f = open(DATA_PATH + self.f_name, "w")
            _temp_f.close()
            # # rb+ write in any position
            _f = open(DATA_PATH + self.f_name, "rb+")
            _file_no = _f.fileno()
            _threads = []
            for _ in range(DOWN_MAX_THREAD_NUM):
                dup = os.dup(_file_no)
                fd = os.fdopen(dup, "rb+", -1)
                _threads.append(threading.Thread(target=self.single_download_thread, args=(fd,)))
            for _t in _threads:
                _t.start()
            for _t in _threads:
                _t.join()
            _f.close()
            if self.queue.qsize() > 0:
                return 1
            else:
                return 0
        except Exception as e:
            raise e
            print(e.__doc__, e.__class__)

    def download_flow(self):
        if self.version is None:
            print("GET IMPORTANT ERROR: arg _version is none, please check python scripts.")
            exit(-3)
        if os.path.exists("%s/%s" % (DATA_PATH, self.f_name)):
            print("GET WARN: file exists, please check!")
            exit(-1)
        print("GET INFO: find %s in %s%s, target url=%s" % (self.f_name, self.index, self.version, self.url))
        while True:
            _code = self.download(3)
            if _code == 0:
                print("Download OK!")
                break
            elif _code == 2:
                print("Download Failed, cannot get the size of file")
                break
            else:
                continue


class Installer:
    def __init__(self, _index=BIND_9_INDEX, _version=None, ):
        """
            do nothing
        """
        self.index = _index
        self.version = _version
    
    def install(self, _need_unzip=False):
        if self.version is None:
            print("INSTALL IMPORTANT ERROR: arg _version is none, please check python scripts.")
            return -3

        # # unzip
        if _need_unzip:
            _file_name = DATA_PATH + "bind-%s.tar.gz" % self.version
            if not os.path.exists(_file_name):
                print("INSTALL WARN: file %s not exists, please check!" % _file_name)
                return -1
            try:
                dest_dir = DATA_PATH
                tar = tarfile.open(_file_name)
                names = tar.getnames()
                for name in names:
                    tar.extract(name, dest_dir)
                    print("create file: ", name)
                tar.close()
            except Exception as e:
                print("INSTALL ERROR: unzip failed, file: %s" % _file_name)
                raise e
        # # execute the install.sh script
        _now_dir = os.getcwd()
        _new_dir = DATA_PATH + "bind-" + self.version
        if not os.path.exists(_new_dir):
            print("INSTALL WARN: non-exist dir, creating")
            os.mkdir(_new_dir)
        os.chdir(_new_dir)
        print(_new_dir)
        # # copy install.sh
        shutil.copyfile(SCRIPTS_PATH + "install.sh", _new_dir + "/install.sh")
        _cmd = "sudo sh ./install.sh %s %s" % (
            NAMED_PATH + "bind-%s" % self.version,
            # SCRIPTS_PATH + "config"
            "/etc/named")
        execute_command(_cmd)
        # print(_cmd)
        # _pipe = os.popen(_cmd)
        # print(_pipe.read()) 
        
    def config(self, _index=BIND_9_INDEX, _version=None):    
        if _version is None:
            print("CONFIG IMPORTANT ERROR: arg _version is none, please check python scripts.")
            return -3
        # # 采取统一配置的方法, 在/etc/named文件夹下保存
        

class Run:    
    def __init__(self):
        self.version = ""
        self.run_flag = False
    
    def run(self, _version):
        _cmd = "sudo " + NAMED_PATH + "bind-%s/sbin/named -g" % _version
        self.version = _version
        try:
            self.run_flag = True
            execute_command(_cmd)
            self.version = ""
            self.run_flag = False
        except KeyboardInterrupt:
            self.version = ""
            self.run_flag = False

    @staticmethod
    def flush(_version):
        _cmd = "sudo " + NAMED_PATH + "bind-%s/sbin/rndc flush & sudo rm /var/cache/bind/named_dump.db" % _version
        execute_command(_cmd)

    @staticmethod
    def dumpdb_and_show(_version, _filter):
        _cmd = "sudo " + NAMED_PATH + "bind-%s/sbin/rndc dumpdb -cache && sudo cat /var/cache/bind/named_dump.db | grep %s" % (_version, _filter)
        execute_command(_cmd) 

    @staticmethod
    def check():
        """
            检查53 和 953端口是否被占用, 如果被占用, 清除占用
        """
        _ret = execute_command_with_return("sudo lsof -i:53 | grep named", _line_flag=True)
        _pid = set()
        for line in _ret:
            _pid.add(line.strip().split()[1])
        return len(_pid) > 0, list(_pid)
    
    @staticmethod
    def kill(_pid):
        _cmd = "sudo kill %s" % str(_pid)
        execute_command(_cmd)
    
    def change(self, _new_version):
        """
            1. rndc关闭
        """
        self.stop()
        self.run(_new_version)
    
    def stop(self):
        _flag, _pid = self.check()
        if _flag:
            _cmd = "sudo rndc stop"
            execute_command(_cmd)
            self.kill(_pid[0])
        print("INFO: BIND CLOSED, SOCKET FREE")

def main():
    parser = argparse.ArgumentParser(description="BIND CHANGER\nPOWERED BY NIST at HIT Weihai\n")
    parser.add_argument("option", help="Options: download/install/run/flush/dumpdb/change/stop or d/i/r/f/u/c/s")
    parser.add_argument("--do-not-unzip", action="store_true", help="add need-unzip option to forbin <unzip> option!")
    parser.add_argument("-v", "--version", default="9.10.0", help="version, default to 9.10.0")
    parser.add_argument('-f', "--filter", default="", help="need option dumpdb, to add a filter")
    args = parser.parse_args()
    print(args)
    _version = args.version
    _filter = args.filter
    downloader, installer, runner = Downloader(_index=BIND_9_INDEX, _version=_version), Installer(_index=BIND_9_INDEX, _version=_version), Run()
    _mapping = {
        'download': downloader.download_flow,
        'install': lambda: installer.install(not args.do_not_unzip),
        'run': lambda: runner.run(_version),
        'flush': lambda: runner.flush(_version),
        'dumpdb': lambda: runner.dumpdb_and_show(_version, _filter),
        'change': lambda: runner.change(_version),
        'stop': runner.stop,
        'd': downloader.download_flow,
        'i': lambda: installer.install(not args.do_not_unzip),
        'r': lambda: runner.run(_version),
        'f': lambda: runner.flush(_version),
        'u': lambda: runner.dumpdb_and_show(_version, _filter),
        'c': lambda: runner.change(_version),
        's': runner.stop
    }
    if args.option not in _mapping:
        """分割模式"""
        for _opt in args.option:
            if _opt in _mapping:
                _mapping[_opt]()
            else:
                print("Invaild Option")
                exit(-1)
    else:
        """正常模式"""
        # print(args.option)
        _mapping[args.option]()
    


if __name__ == "__main__":
    main()
